// End-to-end behaviour test in a simulated browser (jsdom) with React StrictMode ON.
// jsdom is NOT a project dependency. Install it ad hoc first:
//   npm install --no-save jsdom
// then run:  node scripts/dom-test.mjs
// It clicks through the real app and checks what lands in window.dataLayer.
import { JSDOM } from 'jsdom';

const dom = new JSDOM('<!doctype html><html lang="en"><head><title>t</title></head><body><div id="root"></div></body></html>', {
  url: 'http://localhost:5173/?utm_source=test&utm_medium=cpc&cid=c1',
  pretendToBeVisual: true,
});
const w = dom.window;
const defineGlobal = (k, v) => Object.defineProperty(globalThis, k, { value: v, configurable: true, writable: true });
['window', 'document', 'navigator', 'localStorage', 'history', 'location', 'HTMLElement', 'Event', 'MouseEvent', 'CustomEvent', 'KeyboardEvent', 'getComputedStyle', 'requestAnimationFrame', 'cancelAnimationFrame']
  .forEach((k) => defineGlobal(k, w[k]));
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
w.scrollTo = () => {};
// Minimal IntersectionObserver: reports "visible" right after observe().
class FakeIO {
  constructor(cb) { this.cb = cb; }
  observe(el) { setTimeout(() => this.cb([{ isIntersecting: true, target: el }]), 0); }
  unobserve() {}
  disconnect() {}
}
defineGlobal('IntersectionObserver', FakeIO);
w.IntersectionObserver = FakeIO;
// Stop jsdom trying to "navigate" when links are clicked (we only care about the handlers).
w.document.addEventListener('click', (e) => { const a = e.target.closest?.('a'); if (a && (a.target === '_blank' || a.hasAttribute('download'))) e.preventDefault(); });

const { createServer } = await import('vite');
const vite = await createServer({ server: { middlewareMode: true }, appType: 'custom', logLevel: 'error' });
const React = (await import('react')).default;
const { act } = await import('react');
const { createRoot } = await import('react-dom/client');
const { BrowserRouter } = await import('react-router-dom');
const { default: App } = await vite.ssrLoadModule('/src/App.jsx');
const { CartProvider } = await vite.ssrLoadModule('/src/context/CartContext.jsx');
const { ToastProvider } = await vite.ssrLoadModule('/src/context/ToastContext.jsx');
await vite.ssrLoadModule('/src/analytics/dataLayer.js');

let passed = 0, failed = 0;
const check = (name, ok, detail = '') => { ok ? (passed++, console.log(`  PASS  ${name}`)) : (failed++, console.log(`  FAIL  ${name} ${detail}`)); };
const section = (t) => console.log(`\n${t}`);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const ev = (name) => w.dataLayer.filter((e) => e.event === name);
const text = () => document.body.textContent;
const find = (sel, t) => $$(sel).find((e) => e.textContent.trim().includes(t));
const settle = (ms = 30) => act(async () => { await sleep(ms); });
const click = async (el) => { if (!el) throw new Error('click target not found'); await act(async () => { el.dispatchEvent(new w.MouseEvent('click', { bubbles: true, cancelable: true })); await sleep(10); }); };
const type = async (el, value) => {
  const proto = el instanceof w.HTMLTextAreaElement ? w.HTMLTextAreaElement.prototype : w.HTMLInputElement.prototype;
  await act(async () => { Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value); el.dispatchEvent(new w.Event('input', { bubbles: true })); });
};
const choose = async (el, value) => act(async () => { Object.getOwnPropertyDescriptor(w.HTMLSelectElement.prototype, 'value').set.call(el, value); el.dispatchEvent(new w.Event('change', { bubbles: true })); });
const submit = async (form) => act(async () => { form.dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true })); await sleep(10); });

let root;
async function mountApp() {
  root = createRoot(document.getElementById('root'));
  await act(async () => {
    root.render(React.createElement(React.StrictMode, null,
      React.createElement(BrowserRouter, null,
        React.createElement(ToastProvider, null, React.createElement(CartProvider, null, React.createElement(App))))));
    await sleep(50);
  });
  await settle(50); // effects (e.g. IntersectionObserver setup) flush when act() exits, so wait again
}
await mountApp();

section('Home + StrictMode');
check('exactly ONE page_view on first load (StrictMode safe)', ev('page_view').length === 1, `got ${ev('page_view').length}`);
check('page_view has campaign params from URL', ev('page_view')[0].campaign?.utm_source === 'test' && ev('page_view')[0].campaign?.cid === 'c1');
const imps = ev('product_impression');
const keys = imps.map((e) => `${e.ecommerce.items[0].listName}|${e.ecommerce.items[0].productId}`);
check('featured products produce impressions (7)', imps.length === 7, `got ${imps.length}`);
check('no duplicate impressions', new Set(keys).size === keys.length);
check('impression items carry position + listName', imps.every((e) => e.ecommerce.items[0].position >= 1 && e.ecommerce.items[0].listName === 'Featured Products'));

section('Carousel, banners, categories');
await click(find('button', '') && $$('button[aria-label="Next banner"]')[0]);
check('next banner changes slide (no autoplay)', text().includes('Step into comfort'));
await click(find('a', 'Shop footwear'));
check('banner_click has promotion object', ev('banner_click')[0]?.promotion?.promotionId === 'PROMO-STEP-02' && ev('banner_click')[0].promotion.position === 'hero_2');
await settle(450);
check('landed on footwear listing', location.pathname === '/products' && location.search.includes('category=footwear'));
check('page_view fired for listing', ev('page_view').at(-1).pageName === 'shopsphere:products:footwear');

section('Listing filters + sorting');
await click($$('label.check').find((l) => l.textContent.includes('Kaleo')).querySelector('input'));
check('filter_apply for brand with resultCount', ev('filter_apply').at(-1)?.filterName === 'brand' && ev('filter_apply').at(-1).resultCount === 3, JSON.stringify(ev('filter_apply').at(-1)));
check('brand filter synced to URL', location.search.includes('brand=Kaleo'));
await choose(document.getElementById('sort'), 'price-asc');
check('sort_apply fired + URL synced', ev('sort_apply').at(-1)?.sortOption === 'price-asc' && location.search.includes('sort=price-asc'));
const firstTitle = $$('.card__title')[0].textContent;
check('sorted by price ascending (cheapest first)', firstTitle === 'Court Classic Sports Sandals', firstTitle);
await click($$('label.check').find((l) => l.textContent.includes('In stock')).querySelector('input'));
await click(find('button', 'Reset filters'));
check('reset clears URL filters', !location.search.includes('brand') && !location.search.includes('sort'));

section('Product click -> detail -> add to cart');
const pageViewsBefore = ev('page_view').length;
await settle(30);
await click($$('.card__link')[0]);
await settle(30);
check('product_click has position and listName', ev('product_click').at(-1)?.ecommerce.items[0].position === 1 && ev('product_click').at(-1).ecommerce.items[0].listName === 'Category: Footwear');
check('product_view fired once', ev('product_view').length === 1 && ev('product_view')[0].ecommerce.items[0].listName === 'Category: Footwear');
check('exactly one new page_view for the product page', ev('page_view').length === pageViewsBefore + 1);
await click(find('button', '+')); // quantity 2
await click(find('button', 'Add to cart'));
const atc = ev('add_to_cart')[0];
check('add_to_cart reports quantity 2 and cart totals', atc?.ecommerce.items[0].quantity === 2 && atc.ecommerce.cartQuantity === 2, JSON.stringify(atc?.ecommerce));
check('cart persisted in localStorage (shopsphere_cart)', JSON.parse(localStorage.getItem('shopsphere_cart'))[0].quantity === 2);
check('toast shown', text().includes('added to cart'));
check('header count is live', $$('.cart-link__count')[0].textContent === '2');

section('Search');
await type(document.getElementById('site-search'), 'SHOES');
await submit($$('form[role="search"]')[0]);
await settle(30);
check('search_submit has term and resultCount', ev('search_submit')[0]?.searchTerm === 'SHOES' && ev('search_submit')[0].resultCount === 4, JSON.stringify(ev('search_submit')[0]));
check('URL is /search?q=SHOES (case-insensitive match works)', location.pathname === '/search' && $$('.card').length === 4, String($$('.card').length));
await click($$('.card__link')[1]);
check('search_result_click records position 2', ev('search_result_click')[0]?.position === 2 && ev('search_result_click')[0].searchTerm === 'SHOES');
check('result click did NOT also send product_click', ev('product_click').length === 1);
await type(document.getElementById('site-search'), 'zzzz');
await submit($$('form[role="search"]')[0]);
await settle(30);
check('search_empty fired once', ev('search_empty').length === 1 && text().includes('No results for'));

section('Cart');
await click($$('a.cart-link')[0]);
await settle(30);
check('cart_view fired once', ev('cart_view').length === 1);
await click($$('button[aria-label="Decrease quantity"]')[0]);
check('update_quantity has previous/new', ev('update_quantity').at(-1)?.previousQuantity === 2 && ev('update_quantity').at(-1).newQuantity === 1);
const qtyInput = $$('.qty__input')[0];
await type(qtyInput, '999');
await act(async () => { qtyInput.dispatchEvent(new w.Event('blur', { bubbles: true })); qtyInput.blur(); });
await click($$('button[aria-label="Increase quantity"]')[0]);
const line = JSON.parse(localStorage.getItem('shopsphere_cart'))[0];
check('quantity is capped at stock', line.quantity <= 100 && line.quantity >= 1);
await type($$('.qty__input')[0], '0');
await act(async () => { $$('.qty__input')[0].dispatchEvent(new w.KeyboardEvent('keydown', { key: 'Enter', bubbles: true })); await sleep(10); });
check('quantity cannot drop below 1', JSON.parse(localStorage.getItem('shopsphere_cart'))[0].quantity === 1);
check('summary shows shipping, tax and total', ['Subtotal', 'Shipping', 'Tax (18% GST)', 'Total'].every((s) => text().includes(s)));

section('Checkout');
await click(find('a', 'Proceed to checkout'));
await settle(30);
check('checkout_start fired once', ev('checkout_start').length === 1);
check('demo-only notice visible', text().includes('Demo only - do not enter real data'));
await submit($$('form')[$$('form').length - 1]);
check('empty shipping form shows visible errors', $$('.field__error').length === 5, String($$('.field__error').length));
check('shipping_submit success:false and 5 form_error events', ev('shipping_submit').at(-1)?.success === false && ev('form_error').length === 5);
check('form_error carries no field values', ev('form_error').every((e) => Object.keys(e).sort().join() === 'errorType,eventId,event,fieldName,formName,timestamp'.split(',').sort().join()));
const F = { fullName: 'Zed Qwerty', address: '77 Nowhere Lane', city: 'Testville', pin: '110011', phone: '9123456789' };
for (const [id, v] of Object.entries(F)) await type(document.getElementById(id), v);
await submit($$('form')[$$('form').length - 1]);
check('valid shipping advances to payment', text().includes('Payment method') && ev('shipping_submit').at(-1).success === true);
await submit($$('form')[$$('form').length - 1]);
check('payment required error', text().includes('Choose a payment method'));
await click($$('input[name="paymentMethod"]')[1]);
check('payment_method_select fired with upi', ev('payment_method_select').at(-1)?.paymentMethod === 'upi');
await submit($$('form')[$$('form').length - 1]);
check('review step shown', text().includes('Review and place order'));
check('no order exists before Place order', localStorage.getItem('shopsphere_last_order') === null && ev('purchase').length === 0);
const placeBtn = find('button', 'Place order');
await act(async () => { placeBtn.dispatchEvent(new w.MouseEvent('click', { bubbles: true })); placeBtn.dispatchEvent(new w.MouseEvent('click', { bubbles: true })); await sleep(30); }); // double click
await settle(30);
check('on /order-confirmation', location.pathname === '/order-confirmation');
const stored = JSON.parse(localStorage.getItem('shopsphere_last_order'));
check('stored order id matches ORDER-YYYYMMDD-XXXXXX', /^ORDER-\d{8}-[A-Z0-9]{6}$/.test(stored.orderId), stored.orderId);
check('exactly ONE purchase despite double-click', ev('purchase').length === 1);
const pur = ev('purchase')[0];
check('purchase transaction matches stored order', pur.ecommerce.transaction.orderId === stored.orderId && pur.ecommerce.transaction.revenue === stored.revenue && pur.ecommerce.transaction.tax === stored.tax && pur.ecommerce.transaction.shipping === stored.shipping && pur.ecommerce.transaction.paymentMethod === 'upi');
check('stored order: purchaseTracked true, has items/revenue/shipping/tax', stored.purchaseTracked === true && stored.items.length === 1 && 'revenue' in stored && 'shipping' in stored && 'tax' in stored);
check('cart emptied after order', JSON.parse(localStorage.getItem('shopsphere_cart')).length === 0);
check('confirmation shows the order id', text().includes(stored.orderId));

section('Refresh / revisit of the confirmation page');
await act(async () => root.unmount());
const purchasesBefore = ev('purchase').length;
await mountApp(); // fresh React tree on the same URL = simulated refresh
await settle(30);
check('same order id still shown', text().includes(stored.orderId));
check('refresh did not create a new order', JSON.parse(localStorage.getItem('shopsphere_last_order')).orderId === stored.orderId);
check('refresh did not send another purchase', ev('purchase').length === purchasesBefore);
await act(async () => root.unmount());
const saved = localStorage.getItem('shopsphere_last_order');
localStorage.removeItem('shopsphere_last_order');
await mountApp();
check('no stored order -> friendly redirect message', text().includes('No recent order found'));
check('visiting the URL did NOT create an order', localStorage.getItem('shopsphere_last_order') === null && ev('purchase').length === purchasesBefore);
await act(async () => { await sleep(3700); });
check('auto-redirects to /', location.pathname === '/');
localStorage.setItem('shopsphere_last_order', saved);

section('Cart abandonment');
const addBtn = $$('.card .btn--primary').find((b) => !b.disabled);
await click(addBtn);
const cartBefore = localStorage.getItem('shopsphere_cart');
Object.defineProperty(document, 'visibilityState', { value: 'hidden', configurable: true });
await act(async () => { document.dispatchEvent(new w.Event('visibilitychange')); w.dispatchEvent(new w.Event('pagehide')); document.dispatchEvent(new w.Event('visibilitychange')); });
check('cart_abandon fired exactly once (listeners registered once, deduped)', ev('cart_abandon').length === 1, String(ev('cart_abandon').length));
check('cart_abandon has ecommerce items', ev('cart_abandon')[0].ecommerce.items.length === 1);
check('cart untouched by abandonment', localStorage.getItem('shopsphere_cart') === cartBefore);

section('Newsletter, outbound, download');
Object.defineProperty(document, 'visibilityState', { value: 'visible', configurable: true });
await type(document.getElementById('newsletter-email'), 'not-an-email');
await submit($$('.newsletter__form')[0]);
check('newsletter invalid -> form_error (field + type only)', ev('form_error').at(-1)?.formName === 'newsletter' && ev('form_error').at(-1).errorType === 'invalid_format' && !('value' in ev('form_error').at(-1)));
await type(document.getElementById('newsletter-email'), 'secret.person@example.com');
await submit($$('.newsletter__form')[0]);
check('newsletter_signup fired', ev('newsletter_signup').length === 1);
await click(find('a', 'Adobe Analytics docs'));
check('outbound_click has destination', ev('outbound_click')[0]?.destinationDomain === 'experienceleague.adobe.com');
const out = find('a', 'Adobe Analytics docs');
check('outbound link opens new tab safely', out.target === '_blank' && out.rel.includes('noopener'));
await click(find('a', 'Size guide'));
check('file_download has name + type', ev('file_download')[0]?.fileName === 'shopsphere-size-guide.txt' && ev('file_download')[0].fileType === 'txt');

section('Privacy');
const blob = JSON.stringify(w.dataLayer);
check('no typed PII anywhere in the data layer', !['secret.person', 'Zed Qwerty', '77 Nowhere', 'Testville', '9123456789', '110011'].some((s) => blob.includes(s)));
check('every event has timestamp + unique eventId', w.dataLayer.every((e) => e.timestamp && e.eventId) && new Set(w.dataLayer.map((e) => e.eventId)).size === w.dataLayer.length);

section('Navigation events + 404');
await click(find('a', 'About us'));
check('footer nav_click recorded', ev('nav_click').some((e) => e.linkName === 'about' && e.linkLocation === 'footer'));
await click($$('.main-nav__link').find((a) => a.textContent === 'Apparel'));
check('header category -> category_select', ev('category_select').some((e) => e.categoryName === 'Apparel' && e.source === 'header_menu'));
w.history.pushState({}, '', '/definitely-missing');
await act(async () => { w.dispatchEvent(new w.PopStateEvent('popstate')); await sleep(20); });
check('404 page renders', text().includes('Page not found'));

console.log(`\n${passed} passed, ${failed} failed`);
await vite.close();
process.exit(failed ? 1 : 0);
