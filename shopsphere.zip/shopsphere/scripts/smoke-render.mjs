// Server-render smoke test: renders every route to HTML using Vite's SSR loader.
// It catches crashes in page code (bad imports, undefined values, hook errors).
// It does NOT test browser-only behaviour (clicks, IntersectionObserver, localStorage, StrictMode effects).
// Run with: npm run smoke
import { createServer } from 'vite';

const vite = await createServer({ server: { middlewareMode: true }, appType: 'custom', logLevel: 'error' });
// react / react-dom / react-router-dom are loaded straight from node_modules so the app and this script share one copy.
const React = (await import('react')).default;
const { renderToString } = await import('react-dom/server');
const { StaticRouter } = await import('react-router-dom/server.js');
const { default: App } = await vite.ssrLoadModule('/src/App.jsx');
const { CartProvider } = await vite.ssrLoadModule('/src/context/CartContext.jsx');
const { ToastProvider } = await vite.ssrLoadModule('/src/context/ToastContext.jsx');

const routes = [
  ['/', ['Featured products', 'Pulse Wireless Headphones', 'Shop by category', 'Subscribe']],
  ['/products', ['All products', 'Filters and sorting']],
  ['/products?category=footwear&brand=Kaleo&inStock=1&sort=price-asc', ['Footwear', 'Kaleo']],
  ['/products/SKU-101', ['Pulse Wireless Headphones', 'Add to cart', 'Related products']],
  ['/products/SKU-105', ['Out of stock']],
  ['/products/SKU-999', ['Product not found']],
  ['/search?q=shoes', ['Results for', 'Stride Pro Running Shoes']],
  ['/search?q=HEADPHONES', ['Pulse Wireless Headphones']],
  ['/search?q=zzzz', ['No results for']],
  ['/search', ['Search ShopSphere']],
  ['/cart', ['Your cart is empty']],
  ['/checkout', ['Nothing to check out']],
  ['/order-confirmation', ['No recent order found']],
  ['/about', ['About ShopSphere']],
  ['/contact', ['Contact us', 'Send message']],
  ['/no-such-page', ['Page not found']],
];

let failed = 0;
for (const [url, expected] of routes) {
  try {
    const html = renderToString(
      React.createElement(StaticRouter, { location: url },
        React.createElement(ToastProvider, null,
          React.createElement(CartProvider, null, React.createElement(App))))
    );
    const missing = expected.filter((s) => !html.includes(s));
    if (missing.length) { failed += 1; console.log(`  FAIL  ${url}  missing: ${missing.join(' | ')}`); }
    else console.log(`  PASS  ${url}  (${html.length} chars)`);
  } catch (err) {
    failed += 1;
    console.log(`  FAIL  ${url}  threw: ${err.message}`);
  }
}
await vite.close();
console.log(failed ? `\n${failed} route(s) failed` : '\nAll routes rendered');
process.exit(failed ? 1 : 0);
