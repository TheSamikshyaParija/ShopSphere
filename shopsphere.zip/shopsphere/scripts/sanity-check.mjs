// Quick sanity checks that run in plain Node (no browser, no test framework).
// Run with: npm run check
// Covers: catalogue shape, order ID format + uniqueness, cart maths,
// data layer dedupe guards, purchase-once logic, campaign param parsing.

// Tiny stand-ins for browser globals so the browser-oriented modules can load in Node.
const store = {};
globalThis.window = globalThis;
globalThis.localStorage = {
  getItem: (k) => (k in store ? store[k] : null),
  setItem: (k, v) => { store[k] = String(v); },
  removeItem: (k) => { delete store[k]; },
};

let passed = 0;
let failed = 0;
function check(name, condition, detail = '') {
  if (condition) { passed += 1; console.log(`  PASS  ${name}`); }
  else { failed += 1; console.log(`  FAIL  ${name} ${detail}`); }
}
const section = (t) => console.log(`\n${t}`);

const { products, categories } = await import('../src/data/products.js');
const { generateOrderId, ORDER_ID_PATTERN } = await import('../src/utils/orderId.js');
const { calculateTotals } = await import('../src/utils/cartMath.js');
const dl = await import('../src/analytics/dataLayer.js');
const { trackPurchaseOnce, loadOrder, saveOrder } = await import('../src/analytics/orderStorage.js');

section('Catalogue');
check('24 products', products.length === 24);
check('6 products in each of 4 categories', categories.every((c) => products.filter((p) => p.productCategory === c.name).length === 6));
check('unique SKU ids in format SKU-NNN', new Set(products.map((p) => p.productId)).size === 24 && products.every((p) => /^SKU-\d{3}$/.test(p.productId)));
check('all required fields present', products.every((p) => ['productName', 'productCategory', 'brand', 'price', 'currency', 'rating', 'stock', 'description', 'tags', 'isFeatured'].every((f) => f in p)));
check('currency is INR everywhere', products.every((p) => p.currency === 'INR'));

section('Order ID');
const sample = generateOrderId(new Date(2026, 9, 22));
check('format ORDER-YYYYMMDD-XXXXXX', ORDER_ID_PATTERN.test(sample), sample);
check('date part matches the given date', sample.startsWith('ORDER-20261022-'), sample);
const ids = new Set(Array.from({ length: 20000 }, () => generateOrderId()));
check('20,000 generated IDs are all unique', ids.size === 20000, `got ${ids.size}`);

section('Cart maths');
const big = calculateTotals([{ price: 2999, quantity: 1 }, { price: 699, quantity: 2 }]);
check('subtotal 4397', big.subtotal === 4397, JSON.stringify(big));
check('free shipping at/above 1999', big.shipping === 0);
check('tax = 18% of subtotal (791.46)', big.tax === 791.46, String(big.tax));
check('total = subtotal + shipping + tax (5188.46)', big.total === 5188.46, String(big.total));
const small = calculateTotals([{ price: 499, quantity: 1 }]);
check('under threshold: shipping 99, tax 89.82, total 687.82', small.shipping === 99 && small.tax === 89.82 && small.total === 687.82, JSON.stringify(small));
const empty = calculateTotals([]);
check('empty cart: everything is 0', empty.subtotal === 0 && empty.shipping === 0 && empty.tax === 0 && empty.total === 0);
check('item count sums quantities', big.itemCount === 3);

section('Data layer guards');
const before = window.dataLayer.length;
check('track() pushes with event, timestamp, eventId', dl.track('test_event', { a: 1 }) === true && window.dataLayer.at(-1).event === 'test_event' && !!window.dataLayer.at(-1).timestamp && !!window.dataLayer.at(-1).eventId);
dl.track('dup_id', {}, {});
const fixedId = 'fixed-id-1';
dl.track('same_id', { eventId: fixedId });
const countAfterFirst = window.dataLayer.length;
const secondResult = dl.track('same_id', { eventId: fixedId });
check('same eventId cannot push twice', secondResult === false && window.dataLayer.length === countAfterFirst);
dl.track('once_event', {}, { onceKey: 'k1' });
const c2 = window.dataLayer.length;
check('same onceKey cannot push twice', dl.track('once_event', {}, { onceKey: 'k1' }) === false && window.dataLayer.length === c2);
dl.forgetOnceKeys('k');
check('forgetOnceKeys re-enables a key', dl.track('once_event', {}, { onceKey: 'k1' }) === true);
check('events were appended in order', window.dataLayer.length > before);

section('Purchase fires once');
const order = {
  orderId: generateOrderId(),
  createdAt: new Date().toISOString(),
  currency: 'INR',
  items: [{ productId: 'SKU-101', productName: 'Pulse Wireless Headphones', productCategory: 'Electronics', brand: 'Auralux', price: 2999, quantity: 1, currency: 'INR' }],
  subtotal: 2999, revenue: 2999, shipping: 0, tax: 539.82, total: 3538.82, paymentMethod: 'cod', purchaseTracked: false,
};
saveOrder(order);
const purchasesBefore = window.dataLayer.filter((e) => e.event === 'purchase').length;
const updated = trackPurchaseOnce(order);
const purchases1 = window.dataLayer.filter((e) => e.event === 'purchase');
check('first call pushes exactly one purchase', purchases1.length === purchasesBefore + 1);
check('purchase carries transaction fields', purchases1.at(-1).ecommerce.transaction.orderId === order.orderId && purchases1.at(-1).ecommerce.transaction.revenue === 2999 && purchases1.at(-1).ecommerce.transaction.paymentMethod === 'cod');
check('returned order has purchaseTracked true', updated.purchaseTracked === true);
check('stored order flag flipped to true', loadOrder().purchaseTracked === true);
trackPurchaseOnce(order); // stale copy still says false -> in-memory guard must block it
trackPurchaseOnce(loadOrder()); // fresh copy says true -> flag must block it
check('repeat calls do not push a second purchase', window.dataLayer.filter((e) => e.event === 'purchase').length === purchasesBefore + 1);
const storedKeys = Object.keys(loadOrder());
check('stored order has no personal fields', !['fullName', 'name', 'address', 'city', 'pin', 'phone', 'email'].some((k) => storedKeys.includes(k)), storedKeys.join(','));

section('page_view and campaign params');
check('parseCampaignParams reads utm_* and cid', JSON.stringify(dl.parseCampaignParams('?utm_source=newsletter&utm_medium=email&utm_campaign=diwali&cid=abc&other=1')) === JSON.stringify({ utm_source: 'newsletter', utm_medium: 'email', utm_campaign: 'diwali', cid: 'abc' }));
check('parseCampaignParams returns {} when none', Object.keys(dl.parseCampaignParams('?q=shoes')).length === 0);
globalThis.location = { href: 'http://localhost:5173/?utm_source=google&utm_medium=cpc', search: '?utm_source=google&utm_medium=cpc', pathname: '/' };
globalThis.document = { referrer: 'https://example.com/', title: 'Home | ShopSphere' };
dl.setPageState({ pageName: 'shopsphere:home', pageType: 'home', siteSection: 'home' });
const pv = window.dataLayer.filter((e) => e.event === 'page_view').at(-1);
check('page_view has all required fields', ['pageName', 'pageType', 'siteSection', 'pageUrl', 'pageTitle', 'referrer', 'language'].every((f) => f in pv));
check('page_view includes campaign when present', pv.campaign?.utm_source === 'google' && pv.campaign?.utm_medium === 'cpc');
check('first referrer is document.referrer', pv.referrer === 'https://example.com/');

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
