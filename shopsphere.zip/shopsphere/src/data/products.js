// Mock catalogue. Prices are in INR. `mrp` (optional) is the struck-through
// price used to show sale badges.
export const categories = [
  { slug: 'electronics', name: 'Electronics', blurb: 'Audio, wearables and everyday tech' },
  { slug: 'footwear', name: 'Footwear', blurb: 'Running, casual and formal pairs' },
  { slug: 'apparel', name: 'Apparel', blurb: 'Comfortable basics and ethnic wear' },
  { slug: 'home-kitchen', name: 'Home & Kitchen', blurb: 'Cookware and small appliances' },
];

const p = (n, productName, productCategory, brand, price, mrp, rating, stock, description, tags, isFeatured = false) => ({
  productId: `SKU-${100 + n}`,
  productName,
  productCategory,
  brand,
  price,
  mrp,
  currency: 'INR',
  rating,
  stock,
  description,
  tags,
  isFeatured,
});

export const products = [
  // ---- Electronics (SKU-101..106)
  p(1, 'Pulse Wireless Headphones', 'Electronics', 'Auralux', 2999, 4499, 4.4, 25, 'Over-ear Bluetooth headphones with 30-hour battery life and soft memory-foam cushions.', ['headphones', 'bluetooth', 'audio', 'wireless'], true),
  p(2, 'Beat Buds True Wireless Earbuds', 'Electronics', 'Auralux', 1799, 2499, 4.1, 60, 'Compact earbuds with touch controls, a pocket-sized case and IPX4 sweat resistance.', ['earbuds', 'bluetooth', 'audio']),
  p(3, 'Orbit Smartwatch S2', 'Electronics', 'Nexa', 4499, 5999, 4.3, 18, 'AMOLED smartwatch with heart-rate tracking, sleep insights and 7-day battery.', ['smartwatch', 'fitness', 'wearable'], true),
  p(4, 'Volt 20000mAh Power Bank', 'Electronics', 'Nexa', 1499, null, 4.5, 80, 'Fast-charging power bank with dual USB-A and USB-C output.', ['powerbank', 'charger', 'travel']),
  p(5, 'Echo Mini Bluetooth Speaker', 'Electronics', 'Auralux', 1299, 1899, 4.0, 0, 'Palm-sized waterproof speaker with surprisingly full sound.', ['speaker', 'bluetooth', 'audio', 'portable']),
  p(6, 'Glide Wireless Mouse', 'Electronics', 'Keyra', 699, 999, 4.2, 120, 'Silent-click wireless mouse with adjustable DPI for work and travel.', ['mouse', 'wireless', 'computer', 'office']),

  // ---- Footwear (SKU-107..112)
  p(7, 'Stride Pro Running Shoes', 'Footwear', 'Fleetfoot', 3499, 4999, 4.5, 40, 'Lightweight running shoes with cushioned midsole and breathable mesh upper.', ['shoes', 'running', 'sports', 'sneakers'], true),
  p(8, 'Urban Walk Canvas Sneakers', 'Footwear', 'Fleetfoot', 1599, 2199, 4.1, 55, 'Everyday canvas sneakers with a flexible rubber sole.', ['shoes', 'sneakers', 'casual', 'canvas']),
  p(9, 'Heritage Leather Loafers', 'Footwear', 'Kaleo', 2799, 3499, 4.3, 22, 'Slip-on leather loafers with a padded insole, made for long office days.', ['shoes', 'formal', 'leather', 'loafers']),
  p(10, 'Trail Blazer Hiking Boots', 'Footwear', 'Kaleo', 4299, 5499, 4.6, 12, 'Water-resistant boots with deep-grip soles for uneven trails.', ['boots', 'hiking', 'outdoor', 'shoes']),
  p(11, 'Breeze Flip Flops', 'Footwear', 'Fleetfoot', 399, 599, 3.9, 150, 'Soft-footbed flip flops for the beach, pool or home.', ['slippers', 'flipflops', 'casual', 'summer']),
  p(12, 'Court Classic Sports Sandals', 'Footwear', 'Kaleo', 1199, null, 4.0, 35, 'Adjustable sports sandals with a contoured arch support.', ['sandals', 'sports', 'casual']),

  // ---- Apparel (SKU-113..118)
  p(13, 'Everyday Cotton T-Shirt', 'Apparel', 'Threadly', 499, 799, 4.2, 200, 'Soft 100% cotton crew-neck tee in a relaxed fit.', ['tshirt', 'cotton', 'casual', 'basics'], true),
  p(14, 'Slim Fit Stretch Jeans', 'Apparel', 'Denimo', 1799, 2599, 4.1, 70, 'Mid-rise slim jeans with comfortable stretch denim.', ['jeans', 'denim', 'pants']),
  p(15, 'Festive Cotton Kurta', 'Apparel', 'Rangoli', 1299, 1999, 4.4, 45, 'Straight-cut cotton kurta with subtle embroidery at the collar.', ['kurta', 'ethnic', 'festive', 'cotton'], true),
  p(16, 'Hooded Fleece Sweatshirt', 'Apparel', 'Threadly', 1499, 2199, 4.3, 30, 'Warm fleece hoodie with kangaroo pocket and ribbed cuffs.', ['hoodie', 'winter', 'sweatshirt']),
  p(17, 'Quick-Dry Sports Shorts', 'Apparel', 'Denimo', 599, null, 4.0, 90, 'Lightweight shorts with a zipped pocket for workouts.', ['shorts', 'sports', 'gym']),
  p(18, 'Linen Summer Shirt', 'Apparel', 'Rangoli', 1399, 1899, 4.2, 0, 'Breathable linen shirt, perfect for warm weather.', ['shirt', 'linen', 'summer', 'casual']),

  // ---- Home & Kitchen (SKU-119..124)
  p(19, 'Chef Pro Non-Stick Pan Set', 'Home & Kitchen', 'Hearthware', 2199, 3199, 4.4, 28, 'Three-piece non-stick pan set with cool-touch handles.', ['cookware', 'pan', 'kitchen', 'nonstick'], true),
  p(20, 'Brew Master Electric Kettle', 'Home & Kitchen', 'Hearthware', 999, 1499, 4.3, 65, '1.5 litre stainless steel kettle with auto shut-off.', ['kettle', 'appliance', 'kitchen', 'tea']),
  p(21, 'Whisk Hand Blender', 'Home & Kitchen', 'Zestio', 1599, 2299, 4.2, 33, '400W hand blender with a detachable steel shaft.', ['blender', 'appliance', 'kitchen']),
  p(22, 'Cozy Weave Cotton Bedsheet', 'Home & Kitchen', 'Zestio', 1199, 1799, 4.1, 48, 'Double bedsheet in 180-thread-count cotton with two pillow covers.', ['bedsheet', 'bedroom', 'cotton', 'home']),
  p(23, 'Airtight Storage Jar Set', 'Home & Kitchen', 'Hearthware', 799, null, 4.5, 100, 'Set of six airtight jars for pantry staples.', ['storage', 'jars', 'kitchen', 'pantry']),
  p(24, 'Lumen LED Desk Lamp', 'Home & Kitchen', 'Zestio', 1099, 1599, 4.3, 38, 'Dimmable LED lamp with three colour temperatures and a USB port.', ['lamp', 'lighting', 'desk', 'home'], true),
];

export function getProductById(productId) {
  return products.find((item) => item.productId === productId);
}

export function getCategoryBySlug(slug) {
  return categories.find((c) => c.slug === slug);
}

/** Case-insensitive search across name, category, brand and tags. Every word must match. */
export function searchProducts(query) {
  const terms = String(query || '').toLowerCase().split(/\s+/).filter(Boolean);
  if (terms.length === 0) return [];
  return products.filter((item) => {
    const haystack = [item.productName, item.productCategory, item.brand, ...item.tags].join(' ').toLowerCase();
    return terms.every((t) => haystack.includes(t));
  });
}

// ---- Banners and promotions (used for banner_click / promo_click) ----------
export const homepageBanners = [
  {
    promotionId: 'PROMO-SUMMER-01',
    promotionName: 'Summer Sound Sale',
    creative: 'hero-audio-sale',
    position: 'hero_1',
    target: '/products?category=electronics',
    title: 'Summer Sound Sale',
    subtitle: 'Headphones, earbuds and speakers with up to 35% off.',
    cta: 'Shop electronics',
    theme: 'blue',
  },
  {
    promotionId: 'PROMO-STEP-02',
    promotionName: 'Step Into Comfort',
    creative: 'hero-footwear-new',
    position: 'hero_2',
    target: '/products?category=footwear',
    title: 'Step into comfort',
    subtitle: 'Running shoes, loafers and sandals for every pace.',
    cta: 'Shop footwear',
    theme: 'green',
  },
  {
    promotionId: 'PROMO-HOME-03',
    promotionName: 'Kitchen Refresh',
    creative: 'hero-kitchen-refresh',
    position: 'hero_3',
    target: '/products?category=home-kitchen',
    title: 'Refresh your kitchen',
    subtitle: 'Cookware and small appliances that make cooking easier.',
    cta: 'Shop home & kitchen',
    theme: 'amber',
  },
];

export const promoBanners = [
  {
    promotionId: 'PROMO-FREESHIP-04',
    promotionName: 'Free Shipping Over 1999',
    creative: 'promo-free-shipping',
    position: 'promo_1',
    target: '/products',
    title: 'Free shipping above ₹1,999',
    subtitle: 'Applied automatically at checkout.',
    theme: 'ink',
  },
  {
    promotionId: 'PROMO-FESTIVE-05',
    promotionName: 'Festive Wear Edit',
    creative: 'promo-festive-wear',
    position: 'promo_2',
    target: '/products?category=apparel',
    title: 'The festive wear edit',
    subtitle: 'Kurtas and cotton basics from ₹499.',
    theme: 'coral',
  },
];
