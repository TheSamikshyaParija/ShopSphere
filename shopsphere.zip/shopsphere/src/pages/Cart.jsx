import { Link } from 'react-router-dom';
import usePageView from '../analytics/usePageView.js';
import useOnce from '../analytics/useOnce.js';
import { track } from '../analytics/dataLayer.js';
import { EVENTS } from '../analytics/events.js';
import { buildEcommerce } from '../analytics/helpers.js';
import CartItem from '../components/CartItem.jsx';
import { useCart } from '../context/CartContext.jsx';
import { formatCurrency } from '../utils/format.js';
import { FREE_SHIPPING_THRESHOLD } from '../utils/cartMath.js';

export default function Cart() {
  const { lines, totals } = useCart();
  usePageView({ pageName: 'shopsphere:cart', pageType: 'cart', siteSection: 'cart', pageTitle: 'Your cart' });
  useOnce(() => track(EVENTS.CART_VIEW, { ecommerce: buildEcommerce(lines) }));

  if (lines.length === 0) {
    return (
      <div className="container empty">
        <h1>Your cart is empty</h1>
        <p>Add something you like and it will show up here.</p>
        <Link to="/products" className="btn btn--primary">Start shopping</Link>
      </div>
    );
  }

  const toFree = FREE_SHIPPING_THRESHOLD - totals.subtotal;
  return (
    <div className="container">
      <h1 className="page-title">Your cart</h1>
      <div className="cart-layout">
        <ul className="cart-list">
          {lines.map((line) => (<CartItem key={line.productId} line={line} />))}
        </ul>
        <aside className="summary" aria-label="Order summary">
          <h2>Order summary</h2>
          <dl>
            <div><dt>Subtotal ({totals.itemCount} {totals.itemCount === 1 ? 'item' : 'items'})</dt><dd>{formatCurrency(totals.subtotal)}</dd></div>
            <div><dt>Shipping</dt><dd>{totals.shipping === 0 ? 'Free' : formatCurrency(totals.shipping)}</dd></div>
            <div><dt>Tax (18% GST)</dt><dd>{formatCurrency(totals.tax)}</dd></div>
            <div className="summary__total"><dt>Total</dt><dd>{formatCurrency(totals.total)}</dd></div>
          </dl>
          {toFree > 0 && <p className="muted">Add {formatCurrency(toFree)} more for free shipping.</p>}
          <Link to="/checkout" className="btn btn--primary btn--lg btn--block">Proceed to checkout</Link>
        </aside>
      </div>
    </div>
  );
}
