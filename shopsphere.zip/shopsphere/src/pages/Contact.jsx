import { useState } from 'react';
import usePageView from '../analytics/usePageView.js';
import { track } from '../analytics/dataLayer.js';
import { EVENTS } from '../analytics/events.js';
import FormField from '../components/FormField.jsx';
import { collectErrors, validateEmail, validateName, validateText } from '../utils/validators.js';

export default function Contact() {
  usePageView({ pageName: 'shopsphere:contact', pageType: 'content', siteSection: 'help', pageTitle: 'Contact us' });
  const [form, setForm] = useState({ name: '', email: '', topic: '', message: '' });
  const [errors, setErrors] = useState({});
  const [sent, setSent] = useState(false);
  const setField = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  function handleSubmit(e) {
    e.preventDefault();
    const found = collectErrors({
      name: validateName(form.name),
      email: validateEmail(form.email),
      topic: form.topic ? null : { type: 'required', message: 'Choose a topic.' },
      message: validateText(form.message, 'Message', 10),
    });
    setErrors(found);
    // Field NAMES and error codes only. Never the values typed in.
    Object.entries(found).forEach(([fieldName, err]) =>
      track(EVENTS.FORM_ERROR, { formName: 'contact', fieldName, errorType: err.type })
    );
    if (Object.keys(found).length === 0) setSent(true);
  }

  if (sent) {
    return (
      <div className="container empty" role="status">
        <h1>Message received</h1>
        <p>Thanks for writing in. (Demo only: nothing was sent.)</p>
      </div>
    );
  }
  return (
    <div className="container narrow">
      <h1 className="page-title">Contact us</h1>
      <p className="notice notice--warn">Demo only - do not enter real data.</p>
      <form className="panel" onSubmit={handleSubmit} noValidate>
        <FormField id="name" label="Name" value={form.name} onChange={setField} error={errors.name} placeholder="Test Customer" autoComplete="off" />
        <FormField id="email" label="Email" type="email" value={form.email} onChange={setField} error={errors.email} placeholder="test@example.com" autoComplete="off" />
        <FormField id="topic" label="Topic" as="select" value={form.topic} onChange={setField} error={errors.topic}>
          <option value="">Select a topic</option>
          <option value="order">Order question</option>
          <option value="product">Product question</option>
          <option value="other">Something else</option>
        </FormField>
        <FormField id="message" label="Message" as="textarea" rows={5} value={form.message} onChange={setField} error={errors.message} placeholder="How can we help?" />
        <button type="submit" className="btn btn--primary btn--lg">Send message</button>
      </form>
    </div>
  );
}
