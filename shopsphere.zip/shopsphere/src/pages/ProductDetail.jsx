import { useState } from 'react';
import { Link, useLocation, useParams } from 'react-router-dom';
import usePageView from '../analytics/usePageView.js';
import useOnce from '../analytics/useOnce.js';
import { track } from '../analytics/dataLayer.js';
import { EVENTS } from '../analytics/events.js';
import { toProductItem } from '../analytics/helpers.js';
import ProductImage from '../components/ProductImage.jsx';
import ProductGrid from '../components/ProductGrid.jsx';
import Stars from '../components/Stars.jsx';
import { useCart } from '../context/CartContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { getProductById, products } from '../data/products.js';
import { formatCurrency, discountPercent } from '../utils/format.js';

export default function ProductDetail() {
  const { productId } = useParams();
  const location = useLocation();
  const product = getProductById(productId);

  usePageView(
    product
      ? { pageName: `shopsphere:product:${product.productId}`, pageType: 'product', siteSection: 'products', pageTitle: product.productName }
      : { pageName: 'shopsphere:product:not-found', pageType: 'error', siteSection: 'products', pageTitle: 'Product not found' }
  );

  // product_view: once per product. listName/position come from the card that was clicked.
  useOnce(() => {
    if (!product) return;
    const from = location.state || {};
    track(EVENTS.PRODUCT_VIEW, {
      ecommerce: { currency: 'INR', items: [toProductItem(product, { listName: from.listName, position: from.position })] },
    });
  }, productId);

  if (!product) {
    return (
      <div className="container empty">
        <h1>Product not found</h1>
        <p>We couldn't find "{productId}". It may have been removed.</p>
        <Link className="btn btn--primary" to="/products">Browse all products</Link>
      </div>
    );
  }
  // key= resets the quantity/gallery state when moving between products
  return <ProductView key={product.productId} product={product} />;
}

function ProductView({ product }) {
  const { addItem } = useCart();
  const { showToast } = useToast();
  const [qty, setQty] = useState(1);
  const [view, setView] = useState(0);
  const off = discountPercent(product.mrp, product.price);
  const soldOut = product.stock === 0;
  const related = products.filter((p) => p.productCategory === product.productCategory && p.productId !== product.productId).slice(0, 4);

  const setClamped = (n) => setQty(Math.max(1, Math.min(Math.floor(Number(n)) || 1, product.stock)));

  function handleAdd() {
    const { added } = addItem(product, qty, { listName: 'Product Detail' });
    showToast(added ? `${added} × ${product.productName} added to cart` : 'You already have the maximum in stock in your cart');
  }

  return (
    <div className="container">
      <nav className="breadcrumb" aria-label="Breadcrumb">
        <Link to="/products">Products</Link> / <span>{product.productCategory}</span>
      </nav>
      <div className="detail">
        <div className="gallery">
          <div className="gallery__main"><ProductImage product={product} variant={view} /></div>
          <div className="gallery__thumbs">
            {[0, 1, 2, 3].map((v) => (
              <button key={v} type="button" className={`thumb ${v === view ? 'thumb--on' : ''}`} aria-pressed={v === view} aria-label={`Show image ${v + 1}`} onClick={() => setView(v)}>
                <ProductImage product={product} variant={v} />
              </button>
            ))}
          </div>
        </div>

        <div className="detail__info">
          <p className="card__brand">{product.brand}</p>
          <h1 className="detail__title">{product.productName}</h1>
          <Stars rating={product.rating} />
          <p className="price price--lg">
            <span className="price__now">{formatCurrency(product.price)}</span>
            {off > 0 && (<><s className="price__mrp">{formatCurrency(product.mrp)}</s><span className="badge badge--sale badge--inline">{off}% off</span></>)}
          </p>
          <p className={`stock ${soldOut ? 'stock--out' : product.stock <= 15 ? 'stock--low' : ''}`}>
            {soldOut ? 'Out of stock' : product.stock <= 15 ? `Only ${product.stock} left` : 'In stock'}
          </p>
          <p>{product.description}</p>
          <p className="muted">SKU: {product.productId}</p>

          {!soldOut && (
            <div className="detail__buy">
              <div className="qty" role="group" aria-label="Quantity">
                <button type="button" className="qty__btn" onClick={() => setClamped(qty - 1)} disabled={qty <= 1} aria-label="Decrease quantity">−</button>
                <input className="qty__input" type="number" min="1" max={product.stock} value={qty} onChange={(e) => setClamped(e.target.value)} aria-label="Quantity" />
                <button type="button" className="qty__btn" onClick={() => setClamped(qty + 1)} disabled={qty >= product.stock} aria-label="Increase quantity">+</button>
              </div>
              <button type="button" className="btn btn--primary btn--lg" onClick={handleAdd}>Add to cart</button>
            </div>
          )}
        </div>
      </div>

      <section className="section" aria-labelledby="related-heading">
        <h2 id="related-heading" className="section__title">Related products</h2>
        <ProductGrid products={related} listName="Related Products" />
      </section>
    </div>
  );
}
