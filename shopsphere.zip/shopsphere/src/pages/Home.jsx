import { Link } from 'react-router-dom';
import usePageView from '../analytics/usePageView.js';
import { track } from '../analytics/dataLayer.js';
import { EVENTS } from '../analytics/events.js';
import { HeroCarousel, PromoBanner } from '../components/Banner.jsx';
import ProductGrid from '../components/ProductGrid.jsx';
import NewsletterForm from '../components/NewsletterForm.jsx';
import { categories, homepageBanners, promoBanners, products } from '../data/products.js';

export default function Home() {
  usePageView({ pageName: 'shopsphere:home', pageType: 'home', siteSection: 'home', pageTitle: 'Home' });
  const featured = products.filter((p) => p.isFeatured);

  return (
    <>
      <div className="container">
        <HeroCarousel banners={homepageBanners} />

        <div className="promos">
          {promoBanners.map((b) => (
            <PromoBanner key={b.promotionId} banner={b} />
          ))}
        </div>

        <section className="section" aria-labelledby="featured-heading">
          <h2 id="featured-heading" className="section__title">Featured products</h2>
          <ProductGrid products={featured} listName="Featured Products" />
        </section>

        <section className="section" aria-labelledby="categories-heading">
          <h2 id="categories-heading" className="section__title">Shop by category</h2>
          <ul className="tiles">
            {categories.map((c) => (
              <li key={c.slug}>
                <Link
                  to={`/products?category=${c.slug}`}
                  className={`tile tile--${c.slug}`}
                  onClick={() => track(EVENTS.CATEGORY_SELECT, { categoryName: c.name, categorySlug: c.slug, source: 'home_tile' })}
                >
                  <strong>{c.name}</strong>
                  <span>{c.blurb}</span>
                </Link>
              </li>
            ))}
          </ul>
        </section>

        <section className="newsletter" aria-labelledby="newsletter-heading">
          <div>
            <h2 id="newsletter-heading">Get deals in your inbox</h2>
            <p>One short email a week. Demo form: nothing is stored.</p>
          </div>
          <NewsletterForm />
        </section>
      </div>
    </>
  );
}
