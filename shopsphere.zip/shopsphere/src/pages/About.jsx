import usePageView from '../analytics/usePageView.js';

export default function About() {
  usePageView({ pageName: 'shopsphere:about', pageType: 'content', siteSection: 'help', pageTitle: 'About us' });
  return (
    <div className="container narrow">
      <h1 className="page-title">About ShopSphere</h1>
      <p>ShopSphere is a small demo store with 24 products across four categories. It exists so you can practise building a clean analytics implementation on a realistic shopping journey.</p>
      <p>Everything here is simulated: products, payments and orders never leave your browser, and no personal data is collected or sent anywhere.</p>
      <h2>What you can try</h2>
      <p>Browse and filter products, search, build a cart and walk through checkout. Every step pushes a structured event to <code>window.dataLayer</code>.</p>
    </div>
  );
}
