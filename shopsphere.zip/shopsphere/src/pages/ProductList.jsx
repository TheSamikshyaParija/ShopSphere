import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import usePageView from '../analytics/usePageView.js';
import { track } from '../analytics/dataLayer.js';
import { EVENTS } from '../analytics/events.js';
import FilterBar from '../components/FilterBar.jsx';
import ProductGrid from '../components/ProductGrid.jsx';
import { getCategoryBySlug } from '../data/products.js';
import { applyFilters, brandsFor, parseFilters } from '../utils/productFilters.js';

const listNameFor = (slug) => (slug ? `Category: ${getCategoryBySlug(slug).name}` : 'All Products');

export default function ProductList() {
  const [params, setParams] = useSearchParams();
  const filters = useMemo(() => parseFilters(params), [params]);
  const category = getCategoryBySlug(filters.category);
  const products = useMemo(() => applyFilters(filters), [filters]);
  const brandOptions = useMemo(() => brandsFor(filters.category), [filters.category]);
  const listName = listNameFor(filters.category);

  usePageView({
    pageName: `shopsphere:products:${filters.category || 'all'}`,
    pageType: 'listing',
    siteSection: 'products',
    pageTitle: category ? category.name : 'All products',
  });

  // Short fake "loading" so the skeleton state is visible on first load.
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 350);
    return () => clearTimeout(t);
  }, []);

  // Writes new filters into the URL. Unrelated params (like utm_*) are kept.
  function update(next) {
    const merged = { ...filters, ...next };
    const out = new URLSearchParams(params);
    const setOrDelete = (key, value) => (value ? out.set(key, value) : out.delete(key));
    setOrDelete('category', merged.category);
    setOrDelete('minPrice', merged.minPrice);
    setOrDelete('maxPrice', merged.maxPrice);
    setOrDelete('brand', merged.brands.join(','));
    setOrDelete('inStock', merged.inStock ? '1' : '');
    setOrDelete('sort', merged.sort);
    setParams(out);
    return merged;
  }

  const report = (name, value, action, merged) =>
    track(EVENTS.FILTER_APPLY, {
      filterName: name,
      filterValue: value,
      filterAction: action,
      resultCount: applyFilters(merged).length,
      listName: listNameFor(merged.category),
    });

  const onCategory = (slug) => {
    const c = getCategoryBySlug(slug);
    track(EVENTS.CATEGORY_SELECT, { categoryName: c ? c.name : 'All', categorySlug: slug || 'all', source: 'listing_filter' });
    update({ category: slug, brands: [] }); // brands differ per category, so reset them
  };
  const onBrand = (brand, checked) => {
    const brands = checked ? [...filters.brands, brand] : filters.brands.filter((b) => b !== brand);
    report('brand', brand, checked ? 'add' : 'remove', update({ brands }));
  };
  const onInStock = (checked) => report('in_stock', String(checked), 'set', update({ inStock: checked }));
  const onPrice = (min, max) => {
    const clean = (v) => (/^\d+$/.test(v) ? v : '');
    const merged = update({ minPrice: clean(min), maxPrice: clean(max) });
    report('price_range', `${merged.minPrice || '0'}-${merged.maxPrice || 'any'}`, 'set', merged);
  };
  const onSort = (sort) => {
    update({ sort });
    track(EVENTS.SORT_APPLY, { sortOption: sort || 'featured', resultCount: products.length, listName });
  };
  const onReset = () => {
    const merged = update({ minPrice: '', maxPrice: '', brands: [], inStock: false, sort: '' });
    report('all_filters', 'reset', 'reset', merged);
  };

  return (
    <div className="container">
      <h1 className="page-title">{category ? category.name : 'All products'}</h1>
      <div className="listing">
        <FilterBar
          filters={filters}
          brandOptions={brandOptions}
          resultCount={products.length}
          onCategory={onCategory}
          onBrand={onBrand}
          onInStock={onInStock}
          onPrice={onPrice}
          onSort={onSort}
          onReset={onReset}
        />
        <div>
          {!loading && products.length === 0 ? (
            <div className="empty" role="status">
              <h2>No products match your filters</h2>
              <p>Try a wider price range, or clear some filters.</p>
              <button type="button" className="btn btn--primary" onClick={onReset}>Reset filters</button>
            </div>
          ) : (
            <ProductGrid products={products} listName={listName} loading={loading} />
          )}
        </div>
      </div>
    </div>
  );
}
