import { useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import usePageView from '../analytics/usePageView.js';
import useOnce from '../analytics/useOnce.js';
import { track } from '../analytics/dataLayer.js';
import { EVENTS } from '../analytics/events.js';
import { buildEcommerce, toProductItem } from '../analytics/helpers.js';
import { saveOrder, trackPurchaseOnce } from '../analytics/orderStorage.js';
import FormField from '../components/FormField.jsx';
import { useCart } from '../context/CartContext.jsx';
import { formatCurrency } from '../utils/format.js';
import { generateOrderId } from '../utils/orderId.js';
import { collectErrors, validateName, validatePhone, validatePin, validateText } from '../utils/validators.js';

const STEPS = ['Shipping', 'Payment', 'Review'];
const PAYMENT_METHODS = [
  { value: 'card', label: 'Card (simulated)', help: 'No card details are collected in this demo.' },
  { value: 'upi', label: 'UPI (simulated)', help: 'No UPI ID is collected in this demo.' },
  { value: 'cod', label: 'Cash on Delivery', help: 'Pay when the order arrives.' },
];
const EMPTY_FORM = { fullName: '', address: '', city: '', pin: '', phone: '' };

export default function Checkout() {
  const navigate = useNavigate();
  const { lines, totals, clearCart } = useCart();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState(EMPTY_FORM); // lives only in this component: never stored, never tracked
  const [errors, setErrors] = useState({});
  const [paymentMethod, setPaymentMethod] = useState('');
  const [paymentError, setPaymentError] = useState(null);
  const placing = useRef(false); // blocks a double-click on "Place order"

  usePageView({ pageName: 'shopsphere:checkout', pageType: 'checkout', siteSection: 'checkout', pageTitle: 'Checkout' });
  useOnce(() => {
    if (lines.length > 0) track(EVENTS.CHECKOUT_START, { ecommerce: buildEcommerce(lines) });
  });

  if (lines.length === 0) {
    return (
      <div className="container empty">
        <h1>Nothing to check out</h1>
        <p>Your cart is empty.</p>
        <Link to="/products" className="btn btn--primary">Browse products</Link>
      </div>
    );
  }

  const setField = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  function submitShipping(e) {
    e.preventDefault();
    const found = collectErrors({
      fullName: validateName(form.fullName, 'Full name'),
      address: validateText(form.address, 'Address', 8),
      city: validateName(form.city, 'City'),
      pin: validatePin(form.pin),
      phone: validatePhone(form.phone),
    });
    setErrors(found);
    // Only a success flag and error codes go to analytics - no field values.
    track(EVENTS.SHIPPING_SUBMIT, { success: Object.keys(found).length === 0 });
    Object.entries(found).forEach(([fieldName, err]) =>
      track(EVENTS.FORM_ERROR, { formName: 'checkout_shipping', fieldName, errorType: err.type })
    );
    if (Object.keys(found).length === 0) setStep(2);
  }

  function choosePayment(value) {
    setPaymentMethod(value);
    setPaymentError(null);
    track(EVENTS.PAYMENT_METHOD_SELECT, { paymentMethod: value });
  }

  function submitPayment(e) {
    e.preventDefault();
    if (!paymentMethod) {
      const err = { type: 'required', message: 'Choose a payment method to continue.' };
      setPaymentError(err);
      track(EVENTS.FORM_ERROR, { formName: 'checkout_payment', fieldName: 'paymentMethod', errorType: err.type });
      return;
    }
    setStep(3);
  }

  // The ONLY place an order is created.
  function placeOrder() {
    if (placing.current) return;
    placing.current = true;

    const order = {
      orderId: generateOrderId(),
      createdAt: new Date().toISOString(),
      currency: 'INR',
      items: lines.map((l) => toProductItem(l, { quantity: l.quantity })),
      subtotal: totals.subtotal,
      revenue: totals.subtotal, // product revenue: excludes tax and shipping
      shipping: totals.shipping,
      tax: totals.tax,
      total: totals.total,
      paymentMethod,
      purchaseTracked: false,
    };
    saveOrder(order); // 1. persist the order first
    trackPurchaseOnce(order); // 2. send `purchase` once, then flip purchaseTracked to true
    clearCart(); // 3. empty the cart
    navigate('/order-confirmation', { replace: true });
  }

  const methodLabel = PAYMENT_METHODS.find((m) => m.value === paymentMethod)?.label;

  return (
    <div className="container">
      <h1 className="page-title">Checkout</h1>
      <p className="notice notice--warn">Demo only - do not enter real data.</p>

      <ol className="steps" aria-label="Checkout progress">
        {STEPS.map((label, i) => (
          <li key={label} className={i + 1 === step ? 'steps__on' : i + 1 < step ? 'steps__done' : ''} aria-current={i + 1 === step ? 'step' : undefined}>
            {i + 1}. {label}
          </li>
        ))}
      </ol>

      <div className="cart-layout">
        <div className="panel">
          {step === 1 && (
            <form onSubmit={submitShipping} noValidate>
              <h2>Shipping details</h2>
              <FormField id="fullName" label="Full name" value={form.fullName} onChange={setField} error={errors.fullName} placeholder="Test Customer" autoComplete="off" />
              <FormField id="address" label="Address" value={form.address} onChange={setField} error={errors.address} placeholder="123 Demo Street" autoComplete="off" />
              <div className="row">
                <FormField id="city" label="City" value={form.city} onChange={setField} error={errors.city} placeholder="Demo City" autoComplete="off" />
                <FormField id="pin" label="PIN code" value={form.pin} onChange={setField} error={errors.pin} placeholder="6 digits" inputMode="numeric" maxLength={6} autoComplete="off" />
              </div>
              <FormField id="phone" label="Phone" value={form.phone} onChange={setField} error={errors.phone} placeholder="10-digit mobile" inputMode="numeric" maxLength={10} autoComplete="off" />
              <button type="submit" className="btn btn--primary btn--lg">Continue to payment</button>
            </form>
          )}

          {step === 2 && (
            <form onSubmit={submitPayment} noValidate>
              <fieldset className="payment">
                <legend><h2>Payment method</h2></legend>
                {PAYMENT_METHODS.map((m) => (
                  <label key={m.value} className={`option ${paymentMethod === m.value ? 'option--on' : ''}`}>
                    <input type="radio" name="paymentMethod" value={m.value} checked={paymentMethod === m.value} onChange={() => choosePayment(m.value)} />
                    <span><strong>{m.label}</strong><br /><span className="muted">{m.help}</span></span>
                  </label>
                ))}
                {paymentError && <p className="field__error" role="alert">{paymentError.message}</p>}
              </fieldset>
              <div className="btn-row">
                <button type="button" className="btn btn--outline" onClick={() => setStep(1)}>Back</button>
                <button type="submit" className="btn btn--primary btn--lg">Review order</button>
              </div>
            </form>
          )}

          {step === 3 && (
            <div>
              <h2>Review and place order</h2>
              <p><strong>Deliver to:</strong> {form.fullName}, {form.address}, {form.city} {form.pin}</p>
              <p><strong>Payment:</strong> {methodLabel}</p>
              <p className="muted">Nothing is charged. This creates a demo order in your browser only.</p>
              <div className="btn-row">
                <button type="button" className="btn btn--outline" onClick={() => setStep(2)}>Back</button>
                <button type="button" className="btn btn--primary btn--lg" onClick={placeOrder}>Place order</button>
              </div>
            </div>
          )}
        </div>

        <aside className="summary" aria-label="Order summary">
          <h2>Your items</h2>
          <ul className="mini-list">
            {lines.map((l) => (
              <li key={l.productId}><span>{l.productName} × {l.quantity}</span><span>{formatCurrency(l.price * l.quantity)}</span></li>
            ))}
          </ul>
          <dl>
            <div><dt>Subtotal</dt><dd>{formatCurrency(totals.subtotal)}</dd></div>
            <div><dt>Shipping</dt><dd>{totals.shipping === 0 ? 'Free' : formatCurrency(totals.shipping)}</dd></div>
            <div><dt>Tax (18% GST)</dt><dd>{formatCurrency(totals.tax)}</dd></div>
            <div className="summary__total"><dt>Total</dt><dd>{formatCurrency(totals.total)}</dd></div>
          </dl>
        </aside>
      </div>
    </div>
  );
}
