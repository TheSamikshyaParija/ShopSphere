import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import usePageView from '../analytics/usePageView.js';
import { loadOrder } from '../analytics/orderStorage.js';
import { formatCurrency } from '../utils/format.js';

const METHOD_LABELS = { card: 'Card (simulated)', upi: 'UPI (simulated)', cod: 'Cash on Delivery' };

// READ-ONLY page: it shows the stored order. It never creates an order and
// never sends the purchase event (that happens once, when Place Order succeeds).
export default function OrderConfirmation() {
  const navigate = useNavigate();
  const [order] = useState(() => (typeof window === 'undefined' ? null : loadOrder()));

  usePageView(
    order
      ? { pageName: 'shopsphere:order-confirmation', pageType: 'confirmation', siteSection: 'checkout', pageTitle: 'Order confirmed' }
      : { pageName: 'shopsphere:order-confirmation:no-order', pageType: 'redirect', siteSection: 'checkout', pageTitle: 'No recent order' }
  );

  // No order? Send the visitor home after a few seconds.
  useEffect(() => {
    if (order) return undefined;
    const t = setTimeout(() => navigate('/', { replace: true }), 3500);
    return () => clearTimeout(t);
  }, [order, navigate]);

  if (!order) {
    return (
      <div className="container empty" role="status">
        <h1>No recent order found</h1>
        <p>Taking you back to the home page...</p>
        <Link to="/" className="btn btn--primary">Go to home page now</Link>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="panel confirm">
        <h1>Thank you! Your demo order is confirmed.</h1>
        <p>Order ID: <strong className="order-id">{order.orderId}</strong></p>
        <p className="muted">Placed {new Date(order.createdAt).toLocaleString('en-IN')} · Paid with {METHOD_LABELS[order.paymentMethod] || order.paymentMethod}</p>
        <ul className="mini-list">
          {order.items.map((i) => (
            <li key={i.productId}><span>{i.productName} × {i.quantity}</span><span>{formatCurrency(i.price * i.quantity)}</span></li>
          ))}
        </ul>
        <dl className="summary">
          <div><dt>Subtotal</dt><dd>{formatCurrency(order.subtotal)}</dd></div>
          <div><dt>Shipping</dt><dd>{order.shipping === 0 ? 'Free' : formatCurrency(order.shipping)}</dd></div>
          <div><dt>Tax</dt><dd>{formatCurrency(order.tax)}</dd></div>
          <div className="summary__total"><dt>Total</dt><dd>{formatCurrency(order.total)}</dd></div>
        </dl>
        <Link to="/products" className="btn btn--primary">Continue shopping</Link>
      </div>
    </div>
  );
}
