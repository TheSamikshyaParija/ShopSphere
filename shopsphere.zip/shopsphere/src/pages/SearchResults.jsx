import { Link, useSearchParams } from 'react-router-dom';
import usePageView from '../analytics/usePageView.js';
import useOnce from '../analytics/useOnce.js';
import { track } from '../analytics/dataLayer.js';
import { EVENTS } from '../analytics/events.js';
import { toProductItem } from '../analytics/helpers.js';
import ProductGrid from '../components/ProductGrid.jsx';
import { categories, searchProducts } from '../data/products.js';

const SUGGESTIONS = ['shoes', 'headphones', 'kurta', 'kettle', 'cotton'];

export default function SearchResults() {
  const [params] = useSearchParams();
  const q = (params.get('q') || '').trim();
  const results = searchProducts(q);

  // extraKey = q, so a new search term counts as a new page view
  usePageView(
    { pageName: 'shopsphere:search', pageType: 'search', siteSection: 'search', pageTitle: q ? `Search: ${q}` : 'Search' },
    q
  );

  // search_empty once per term that returns nothing
  useOnce(() => {
    if (q && results.length === 0) track(EVENTS.SEARCH_EMPTY, { searchTerm: q, resultCount: 0 });
  }, q);

  // Result click: records which POSITION in the results was clicked.
  function handleResultClick(product, position) {
    track(EVENTS.SEARCH_RESULT_CLICK, {
      searchTerm: q,
      position,
      resultCount: results.length,
      ecommerce: { currency: 'INR', items: [toProductItem(product, { position, listName: 'Search Results' })] },
    });
  }

  const suggestionLinks = (
    <ul className="chips">
      {SUGGESTIONS.map((s) => (
        <li key={s}>
          <Link
            className="chip"
            to={`/search?q=${s}`}
            onClick={() => track(EVENTS.SEARCH_SUBMIT, { searchTerm: s, resultCount: searchProducts(s).length, source: 'suggestion' })}
          >
            {s}
          </Link>
        </li>
      ))}
    </ul>
  );

  if (!q) {
    return (
      <div className="container empty">
        <h1>Search ShopSphere</h1>
        <p>Type a product, brand or category in the search box. Popular searches:</p>
        {suggestionLinks}
      </div>
    );
  }

  return (
    <div className="container">
      <h1 className="page-title">Results for "{q}"</h1>
      <p className="muted" aria-live="polite">{results.length} {results.length === 1 ? 'result' : 'results'}</p>
      {results.length === 0 ? (
        <div className="empty" role="status">
          <h2>No results for "{q}"</h2>
          <p>Check the spelling, or try a broader word. Popular searches:</p>
          {suggestionLinks}
          <p>Or browse a category:</p>
          <ul className="chips">
            {categories.map((c) => (
              <li key={c.slug}>
                <Link className="chip" to={`/products?category=${c.slug}`} onClick={() => track(EVENTS.CATEGORY_SELECT, { categoryName: c.name, categorySlug: c.slug, source: 'search_empty' })}>
                  {c.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      ) : (
        <ProductGrid products={results} listName="Search Results" onProductClick={handleResultClick} />
      )}
    </div>
  );
}
