import { Link } from 'react-router-dom';
import usePageView from '../analytics/usePageView.js';

export default function NotFound() {
  usePageView({ pageName: 'shopsphere:error:404', pageType: 'error', siteSection: 'error', pageTitle: 'Page not found' });
  return (
    <div className="container empty">
      <h1>Page not found</h1>
      <p>The page you're looking for doesn't exist or has moved.</p>
      <Link to="/" className="btn btn--primary">Back to home</Link>
    </div>
  );
}
