import { useEffect, useRef } from 'react';

/**
 * Runs `fn` once per `key` per mounted component. The ref survives React 18
 * StrictMode's dev double-effect, so analytics calls don't fire twice.
 * Pass a new key (e.g. a productId) to run again for new content.
 */
export default function useOnce(fn, key = 'default') {
  const lastKey = useRef(null);
  useEffect(() => {
    if (lastKey.current === key) return;
    lastKey.current = key;
    fn();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
}
