// Saves/loads the completed order ("shopsphere_last_order") and sends the
// purchase event exactly once. Contains NO personal data (no name/address/phone).
import { track } from './dataLayer.js';
import { EVENTS } from './events.js';
import { buildEcommerce } from './helpers.js';

export const ORDER_STORAGE_KEY = 'shopsphere_last_order';

export function saveOrder(order) {
  try {
    window.localStorage.setItem(ORDER_STORAGE_KEY, JSON.stringify(order));
  } catch {
    /* ignore: private mode etc. */
  }
}

/** Reads the stored order. Returns null if missing or malformed. NEVER creates one. */
export function loadOrder() {
  try {
    const order = JSON.parse(window.localStorage.getItem(ORDER_STORAGE_KEY));
    return order && typeof order.orderId === 'string' && Array.isArray(order.items) ? order : null;
  } catch {
    return null;
  }
}

/**
 * Fires `purchase` once for an order. Two guards:
 *  1. order.purchaseTracked flag (survives reloads, stored in localStorage)
 *  2. onceKey "purchase:<orderId>" (in-memory, survives double calls in one page)
 * Returns the (possibly updated) order.
 */
export function trackPurchaseOnce(order) {
  if (order.purchaseTracked) return order;

  const ecommerce = buildEcommerce(order.items, {
    transaction: {
      orderId: order.orderId,
      revenue: order.revenue, // item subtotal, excludes tax and shipping
      tax: order.tax,
      shipping: order.shipping,
      paymentMethod: order.paymentMethod,
    },
  });
  track(EVENTS.PURCHASE, { ecommerce }, { onceKey: `purchase:${order.orderId}` });

  const updated = { ...order, purchaseTracked: true };
  saveOrder(updated);
  return updated;
}
