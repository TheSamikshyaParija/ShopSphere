import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { setPageState } from './dataLayer.js';

// Remembers the last page_view we sent. Lives OUTSIDE React so it survives
// React 18 StrictMode's "mount -> unmount -> mount" dev double-run.
let lastKey = null;

/**
 * Fires ONE page_view per route change.
 * @param {{pageName:string, pageType:string, siteSection:string, pageTitle?:string}} page
 * @param {string} [extraKey] extra value that should count as a "new page"
 *                            (e.g. the search term on /search)
 */
export default function usePageView(page, extraKey = '') {
  const { pathname } = useLocation();

  useEffect(() => {
    const key = `${pathname}|${page.pageName}|${extraKey}`;
    if (key === lastKey) return; // StrictMode second run, or no real change
    lastKey = key;

    // Set the title first so page_view reports the right pageTitle.
    document.title = page.pageTitle ? `${page.pageTitle} | ShopSphere` : 'ShopSphere';
    setPageState(page);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname, page.pageName, extraKey]);
}
