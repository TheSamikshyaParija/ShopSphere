// Cart abandonment detection.
// Listens for the tab being hidden / page being left. If the saved cart still
// has items, it records cart_abandon. It never changes or clears the cart.
import { track } from './dataLayer.js';
import { EVENTS } from './events.js';
import { buildEcommerce } from './helpers.js';
import { getProductById } from '../data/products.js';
import { CART_STORAGE_KEY } from '../context/CartContext.jsx';

let registered = false; // guard: only ever register the listeners once

function readCartLines() {
  try {
    const saved = JSON.parse(window.localStorage.getItem(CART_STORAGE_KEY) || '[]');
    return saved
      .map((i) => ({ ...getProductById(i.productId), quantity: i.quantity }))
      .filter((l) => l.productId && l.quantity > 0);
  } catch {
    return [];
  }
}

function reportAbandon() {
  const lines = readCartLines();
  if (lines.length === 0) return;
  const signature = lines.map((l) => `${l.productId}x${l.quantity}`).join(',');
  const path = window.location.pathname;
  track(
    EVENTS.CART_ABANDON,
    {
      lastPage: path,
      inCheckout: path.startsWith('/checkout'),
      ecommerce: buildEcommerce(lines),
    },
    // Same cart contents -> only one abandon event, even if both
    // visibilitychange and pagehide fire.
    { onceKey: `abandon:${signature}` }
  );
}

export function initCartAbandonment() {
  if (registered || typeof window === 'undefined') return;
  registered = true;
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') reportAbandon();
  });
  window.addEventListener('pagehide', reportAbandon);
}
