import { useEffect } from 'react';
import { track, forgetOnceKeys } from './dataLayer.js';
import { EVENTS } from './events.js';
import { toProductItem } from './helpers.js';

/**
 * Fires product_impression ONCE when a product card is at least half visible.
 * `renderKey` identifies one render of one list; the dedupe key combines it with
 * the productId, so the same product can't be counted twice for the same list render.
 */
export function useProductImpression(ref, product, position, listName, renderKey) {
  useEffect(() => {
    const el = ref.current;
    if (!el || typeof IntersectionObserver === 'undefined') return undefined;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          track(
            EVENTS.PRODUCT_IMPRESSION,
            { ecommerce: { currency: 'INR', items: [toProductItem(product, { position, listName })] } },
            { onceKey: `imp|${renderKey}|${product.productId}` }
          );
          observer.unobserve(el); // we only need the first sighting
        });
      },
      { threshold: 0.5 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [ref, product, position, listName, renderKey]);
}

/** Frees the impression keys of a list when it unmounts, so coming back counts as a new render. */
export function useForgetImpressions(renderKey) {
  useEffect(() => () => forgetOnceKeys(`imp|${renderKey}|`), [renderKey]);
}
