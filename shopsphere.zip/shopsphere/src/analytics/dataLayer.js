// ---------------------------------------------------------------------------
// ShopSphere data layer.
// Everything the site reports goes through track() / setPageState().
// A tag manager (Adobe Data Collection, later) will READ window.dataLayer.
// This file never talks to the network.
// ---------------------------------------------------------------------------
import { EVENTS } from './events.js';

// `window` in the browser; `globalThis` when the sanity script runs in Node.
const root = typeof window !== 'undefined' ? window : globalThis;
root.dataLayer = root.dataLayer || [];

const isDev = Boolean(import.meta.env?.DEV);

// In-memory dedupe guards (reset on full page reload, by design).
const seenEventIds = new Set(); // same eventId can never be pushed twice
const seenOnceKeys = new Set(); // same one-time key (e.g. "purchase:ORDER-...") can never push twice

let idCounter = 0;
export function makeEventId() {
  idCounter += 1;
  return `${Date.now().toString(36)}-${idCounter}-${Math.random().toString(36).slice(2, 8)}`;
}

/**
 * Push one event onto window.dataLayer.
 * @param {string} eventName  snake_case name from EVENTS
 * @param {object} payload    structured data only - never PII, never DOM text
 * @param {{onceKey?: string}} options  onceKey = "push at most once ever" guard
 * @returns {boolean} true if pushed, false if blocked by a dedupe guard
 */
export function track(eventName, payload = {}, options = {}) {
  const eventId = payload.eventId || makeEventId();

  if (seenEventIds.has(eventId)) return false;
  if (options.onceKey) {
    if (seenOnceKeys.has(options.onceKey)) return false;
    seenOnceKeys.add(options.onceKey);
  }
  seenEventIds.add(eventId);

  const entry = {
    event: eventName,
    timestamp: new Date().toISOString(),
    eventId,
    ...payload,
  };
  root.dataLayer.push(entry);

  if (isDev) {
    console.log('[ShopSphere DL]', eventName, entry);
  }
  // Lets the dev-only debug panel update live without patching dataLayer.push.
  if (typeof root.dispatchEvent === 'function' && typeof CustomEvent !== 'undefined') {
    root.dispatchEvent(new CustomEvent('shopsphere:dl', { detail: entry }));
  }
  return true;
}

/** Forget one-time keys that start with a prefix (used when a product list unmounts). */
export function forgetOnceKeys(prefix) {
  for (const key of seenOnceKeys) {
    if (key.startsWith(prefix)) seenOnceKeys.delete(key);
  }
}

/** Reads utm_* and cid from a query string. Returns only params that are present. */
export function parseCampaignParams(search = '') {
  const params = new URLSearchParams(search);
  const out = {};
  ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term', 'cid'].forEach((key) => {
    const value = params.get(key);
    if (value) out[key] = value;
  });
  return out;
}

// The "previous page" for SPA navigation. First page uses document.referrer.
let previousUrl = '';

/**
 * Pushes a page_view event describing the current page.
 * @param {{pageName:string, pageType:string, siteSection:string}} page
 */
export function setPageState(page) {
  const loc = root.location || { href: '', search: '' };
  const doc = root.document || { referrer: '', title: '' };
  const nav = root.navigator || { language: 'en' };

  const campaign = parseCampaignParams(loc.search);
  const payload = {
    pageName: page.pageName,
    pageType: page.pageType,
    siteSection: page.siteSection,
    pageUrl: loc.href,
    pageTitle: doc.title,
    referrer: previousUrl || doc.referrer || '',
    language: nav.language || 'en',
  };
  if (Object.keys(campaign).length) payload.campaign = campaign;

  previousUrl = loc.href;
  return track(EVENTS.PAGE_VIEW, payload);
}
