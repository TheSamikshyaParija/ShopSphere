// Builders for the standard payload shapes, so every component reports
// products and carts in exactly the same structure.

export function round2(n) {
  return Math.round(n * 100) / 100;
}

/** product object: { productId, productName, productCategory, brand, price, quantity, currency, position, listName } */
export function toProductItem(product, { quantity = 1, position, listName } = {}) {
  const item = {
    productId: product.productId,
    productName: product.productName,
    productCategory: product.productCategory,
    brand: product.brand,
    price: product.price,
    quantity,
    currency: product.currency || 'INR',
  };
  if (position !== undefined) item.position = position;
  if (listName) item.listName = listName;
  return item;
}

/** ecommerce object: { currency, items, cartValue, cartQuantity, transaction? } */
export function buildEcommerce(lines, { listName, transaction } = {}) {
  const items = lines.map((line, index) =>
    toProductItem(line, { quantity: line.quantity, position: index + 1, listName })
  );
  const ecommerce = {
    currency: 'INR',
    items,
    cartValue: round2(items.reduce((sum, i) => sum + i.price * i.quantity, 0)),
    cartQuantity: items.reduce((sum, i) => sum + i.quantity, 0),
  };
  if (transaction) ecommerce.transaction = transaction;
  return ecommerce;
}

/** Domain of a URL, for outbound_click. */
export function getDomain(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return '';
  }
}
