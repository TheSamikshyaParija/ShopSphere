// Each validator returns an error object { type, message } or null when valid.
// `type` is a short code used for form_error tracking (never the field value).
const required = (value, label) =>
  String(value ?? '').trim() === '' ? { type: 'required', message: `${label} is required.` } : null;

export function validateName(value, label = 'Name') {
  const r = required(value, label);
  if (r) return r;
  return value.trim().length < 2 ? { type: 'too_short', message: `${label} must be at least 2 characters.` } : null;
}

export function validateEmail(value) {
  const r = required(value, 'Email');
  if (r) return r;
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value.trim())
    ? null
    : { type: 'invalid_format', message: 'Enter a valid email address, like name@example.com.' };
}

export function validatePin(value) {
  const r = required(value, 'PIN code');
  if (r) return r;
  return /^[1-9]\d{5}$/.test(value.trim())
    ? null
    : { type: 'invalid_format', message: 'PIN code must be 6 digits.' };
}

export function validatePhone(value) {
  const r = required(value, 'Phone number');
  if (r) return r;
  return /^[6-9]\d{9}$/.test(value.trim())
    ? null
    : { type: 'invalid_format', message: 'Phone must be a 10-digit Indian mobile number.' };
}

export function validateText(value, label, minLength = 5) {
  const r = required(value, label);
  if (r) return r;
  return value.trim().length < minLength
    ? { type: 'too_short', message: `${label} must be at least ${minLength} characters.` }
    : null;
}

/** Keeps only the failing checks from a map of { fieldName: errorOrNull }. */
export function collectErrors(checks) {
  const errors = {};
  Object.entries(checks).forEach(([field, err]) => {
    if (err) errors[field] = err;
  });
  return errors;
}
