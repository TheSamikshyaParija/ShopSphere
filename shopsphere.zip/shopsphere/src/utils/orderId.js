// Order ID format: ORDER-YYYYMMDD-XXXXXX  (X = A-Z or 0-9)
const CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
const issued = new Set(); // IDs created during this page session

function randomChars(length) {
  let out = '';
  const cryptoObj = globalThis.crypto;
  if (cryptoObj?.getRandomValues) {
    const bytes = new Uint8Array(length);
    cryptoObj.getRandomValues(bytes);
    for (const b of bytes) out += CHARS[b % CHARS.length];
  } else {
    for (let i = 0; i < length; i += 1) out += CHARS[Math.floor(Math.random() * CHARS.length)];
  }
  return out;
}

/** Creates a new order ID. Never returns the same ID twice in one session. */
export function generateOrderId(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  let id;
  do {
    id = `ORDER-${y}${m}${d}-${randomChars(6)}`;
  } while (issued.has(id));
  issued.add(id);
  return id;
}

export const ORDER_ID_PATTERN = /^ORDER-\d{8}-[A-Z0-9]{6}$/;
