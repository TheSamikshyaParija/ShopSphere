import { products, getCategoryBySlug } from '../data/products.js';

export const SORT_OPTIONS = ['price-asc', 'price-desc', 'rating', 'name'];

/** Reads the listing filters out of URL search params (invalid values are ignored). */
export function parseFilters(params) {
  const digits = (v) => (/^\d+$/.test(v || '') ? v : '');
  const category = getCategoryBySlug(params.get('category')) ? params.get('category') : '';
  const sort = SORT_OPTIONS.includes(params.get('sort')) ? params.get('sort') : '';
  return {
    category,
    minPrice: digits(params.get('minPrice')),
    maxPrice: digits(params.get('maxPrice')),
    brands: (params.get('brand') || '').split(',').filter(Boolean),
    inStock: params.get('inStock') === '1',
    sort,
  };
}

/** Applies filters and sorting. Returns a new array. */
export function applyFilters(filters) {
  const category = getCategoryBySlug(filters.category);
  let list = products.filter((p) => {
    if (category && p.productCategory !== category.name) return false;
    if (filters.minPrice && p.price < Number(filters.minPrice)) return false;
    if (filters.maxPrice && p.price > Number(filters.maxPrice)) return false;
    if (filters.brands.length && !filters.brands.includes(p.brand)) return false;
    if (filters.inStock && p.stock === 0) return false;
    return true;
  });
  const sorters = {
    'price-asc': (a, b) => a.price - b.price,
    'price-desc': (a, b) => b.price - a.price,
    rating: (a, b) => b.rating - a.rating,
    name: (a, b) => a.productName.localeCompare(b.productName),
  };
  if (sorters[filters.sort]) list = [...list].sort(sorters[filters.sort]);
  return list;
}

/** Brands available inside a category (or in the whole catalogue). */
export function brandsFor(categorySlug) {
  const category = getCategoryBySlug(categorySlug);
  const pool = category ? products.filter((p) => p.productCategory === category.name) : products;
  return [...new Set(pool.map((p) => p.brand))].sort();
}
