// Formats a number as Indian Rupees, e.g. 1299 -> "₹1,299".
export function formatCurrency(amount) {
  const hasPaise = Math.round(amount * 100) % 100 !== 0;
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: hasPaise ? 2 : 0,
    maximumFractionDigits: 2,
  }).format(amount);
}

/** Percent off between MRP and price (whole number). */
export function discountPercent(mrp, price) {
  if (!mrp || mrp <= price) return 0;
  return Math.round(((mrp - price) / mrp) * 100);
}
