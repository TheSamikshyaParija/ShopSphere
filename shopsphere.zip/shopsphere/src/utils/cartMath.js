// Pure cart maths (no React) so it can be tested from a plain Node script.
export const TAX_RATE = 0.18; // 18% GST (demo)
export const SHIPPING_FEE = 99; // flat INR
export const FREE_SHIPPING_THRESHOLD = 1999; // subtotal at/above this ships free

const round2 = (n) => Math.round(n * 100) / 100;

/** lines: [{ price, quantity }]  ->  { subtotal, shipping, tax, total, itemCount } */
export function calculateTotals(lines) {
  const subtotal = round2(lines.reduce((sum, l) => sum + l.price * l.quantity, 0));
  const itemCount = lines.reduce((sum, l) => sum + l.quantity, 0);
  const shipping = subtotal === 0 || subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_FEE;
  const tax = round2(subtotal * TAX_RATE);
  const total = round2(subtotal + shipping + tax);
  return { subtotal, shipping, tax, total, itemCount };
}
