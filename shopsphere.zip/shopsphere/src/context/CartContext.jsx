import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { getProductById } from '../data/products.js';
import { calculateTotals } from '../utils/cartMath.js';
import { track } from '../analytics/dataLayer.js';
import { EVENTS } from '../analytics/events.js';
import { buildEcommerce } from '../analytics/helpers.js';

export const CART_STORAGE_KEY = 'shopsphere_cart';
const CartContext = createContext(null);

// The cart is saved as a small list: [{ productId, quantity }].
// Full product details are looked up from the catalogue, so prices never go stale.
function loadCart() {
  try {
    const saved = JSON.parse(window.localStorage.getItem(CART_STORAGE_KEY) || '[]');
    if (!Array.isArray(saved)) return [];
    return saved
      .map((entry) => ({ product: getProductById(entry.productId), quantity: Number(entry.quantity) }))
      .filter((e) => e.product && e.product.stock > 0 && Number.isInteger(e.quantity) && e.quantity > 0)
      .map((e) => ({ productId: e.product.productId, quantity: Math.min(e.quantity, e.product.stock) }));
  } catch {
    return []; // no localStorage, or corrupted JSON: start with an empty cart
  }
}

function toLines(items) {
  return items.map((i) => ({ ...getProductById(i.productId), quantity: i.quantity }));
}

export function CartProvider({ children }) {
  const [items, setItems] = useState(loadCart);

  // Persist on every change.
  useEffect(() => {
    try {
      window.localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items));
    } catch {
      /* storage full or blocked: the cart still works in memory */
    }
  }, [items]);

  const lines = useMemo(() => toLines(items), [items]);
  const totals = useMemo(() => calculateTotals(lines), [lines]);

  // meta = { position, listName } describes where the add happened (for analytics).
  const addItem = useCallback(
    (product, quantity = 1, meta = {}) => {
      const existing = items.find((i) => i.productId === product.productId);
      const current = existing ? existing.quantity : 0;
      const newQty = Math.min(current + quantity, product.stock);
      const added = newQty - current;
      if (added <= 0) return { added: 0 }; // out of stock, or already at max

      const next = existing
        ? items.map((i) => (i.productId === product.productId ? { ...i, quantity: newQty } : i))
        : [...items, { productId: product.productId, quantity: newQty }];
      setItems(next);

      const ecommerce = buildEcommerce(toLines(next));
      // The items array of add_to_cart describes only what was ADDED, not the whole cart.
      ecommerce.items = [
        {
          productId: product.productId,
          productName: product.productName,
          productCategory: product.productCategory,
          brand: product.brand,
          price: product.price,
          quantity: added,
          currency: product.currency,
          ...(meta.position !== undefined && { position: meta.position }),
          ...(meta.listName && { listName: meta.listName }),
        },
      ];
      track(EVENTS.ADD_TO_CART, { ecommerce });
      return { added };
    },
    [items]
  );

  const removeItem = useCallback(
    (productId) => {
      const line = items.find((i) => i.productId === productId);
      if (!line) return;
      const next = items.filter((i) => i.productId !== productId);
      setItems(next);
      const product = getProductById(productId);
      const ecommerce = buildEcommerce(toLines(next));
      ecommerce.items = [
        { productId, productName: product.productName, productCategory: product.productCategory, brand: product.brand, price: product.price, quantity: line.quantity, currency: product.currency },
      ];
      track(EVENTS.REMOVE_FROM_CART, { ecommerce });
    },
    [items]
  );

  const setQuantity = useCallback(
    (productId, quantity) => {
      const product = getProductById(productId);
      const line = items.find((i) => i.productId === productId);
      if (!product || !line) return;
      const clamped = Math.max(1, Math.min(Math.floor(Number(quantity)) || 1, product.stock)); // min 1, max stock
      if (clamped === line.quantity) return;
      const next = items.map((i) => (i.productId === productId ? { ...i, quantity: clamped } : i));
      setItems(next);
      const ecommerce = buildEcommerce(toLines(next));
      ecommerce.items = [
        { productId, productName: product.productName, productCategory: product.productCategory, brand: product.brand, price: product.price, quantity: clamped, currency: product.currency },
      ];
      track(EVENTS.UPDATE_QUANTITY, { previousQuantity: line.quantity, newQuantity: clamped, ecommerce });
    },
    [items]
  );

  // Used after a successful order. Deliberately does NOT track anything.
  const clearCart = useCallback(() => setItems([]), []);

  const value = useMemo(
    () => ({ lines, totals, itemCount: totals.itemCount, addItem, removeItem, setQuantity, clearCart }),
    [lines, totals, addItem, removeItem, setQuantity, clearCart]
  );
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used inside <CartProvider>');
  return ctx;
}
