import { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import SearchBar from './SearchBar.jsx';
import { useCart } from '../context/CartContext.jsx';
import { categories } from '../data/products.js';
import { track } from '../analytics/dataLayer.js';
import { EVENTS } from '../analytics/events.js';

export default function Header() {
  const { itemCount } = useCart();
  const [menuOpen, setMenuOpen] = useState(false);
  const close = () => setMenuOpen(false);

  // Category links report category_select; every other link reports nav_click.
  const navClick = (linkName, linkUrl) => {
    track(EVENTS.NAV_CLICK, { linkName, linkUrl, linkLocation: 'header' });
    close();
  };
  const categoryClick = (c) => {
    track(EVENTS.CATEGORY_SELECT, { categoryName: c.name, categorySlug: c.slug, source: 'header_menu' });
    close();
  };

  return (
    <header className="site-header">
      <div className="container site-header__row">
        <Link to="/" className="logo" onClick={() => navClick('logo', '/')}>
          <svg viewBox="0 0 64 64" width="30" height="30" aria-hidden="true">
            <rect width="64" height="64" rx="14" fill="#1d3fd1" />
            <circle cx="32" cy="32" r="17" fill="none" stroke="#fff" strokeWidth="4" />
            <ellipse cx="32" cy="32" rx="7" ry="17" fill="none" stroke="#ffb703" strokeWidth="3.5" />
          </svg>
          <span>ShopSphere</span>
        </Link>

        <button
          type="button"
          className="menu-toggle"
          aria-expanded={menuOpen}
          aria-controls="main-nav"
          onClick={() => setMenuOpen((o) => !o)}
        >
          {menuOpen ? 'Close' : 'Menu'}
        </button>

        <SearchBar />

        <Link to="/cart" className="cart-link" onClick={() => navClick('cart', '/cart')} aria-label={`Cart, ${itemCount} ${itemCount === 1 ? 'item' : 'items'}`}>
          <svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true">
            <path d="M3 4h2.5l2.2 10.5h10.1L20 7H7" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            <circle cx="9.5" cy="19" r="1.5" fill="currentColor" />
            <circle cx="17" cy="19" r="1.5" fill="currentColor" />
          </svg>
          <span className="cart-link__count" aria-hidden="true">{itemCount}</span>
        </Link>
      </div>

      <nav id="main-nav" className={`main-nav ${menuOpen ? 'main-nav--open' : ''}`} aria-label="Main">
        <div className="container main-nav__list">
          <NavLink to="/products" end className="main-nav__link" onClick={() => navClick('all_products', '/products')}>
            All products
          </NavLink>
          {categories.map((c) => (
            <NavLink key={c.slug} to={`/products?category=${c.slug}`} className="main-nav__link" onClick={() => categoryClick(c)}>
              {c.name}
            </NavLink>
          ))}
        </div>
      </nav>
    </header>
  );
}
