// One labelled form control with an accessible error message.
// as = "input" (default) | "textarea" | "select"
export default function FormField({ id, label, error, hint, as: Tag = 'input', children, ...rest }) {
  const errorId = `${id}-error`;
  const hintId = `${id}-hint`;
  const describedBy = [error ? errorId : null, hint ? hintId : null].filter(Boolean).join(' ') || undefined;
  return (
    <div className={`field ${error ? 'field--error' : ''}`}>
      <label htmlFor={id}>{label}</label>
      <Tag id={id} name={id} aria-invalid={error ? 'true' : undefined} aria-describedby={describedBy} {...rest}>
        {children}
      </Tag>
      {hint && !error && <p className="field__hint" id={hintId}>{hint}</p>}
      {error && (
        <p className="field__error" id={errorId} role="alert">
          {error.message}
        </p>
      )}
    </div>
  );
}
