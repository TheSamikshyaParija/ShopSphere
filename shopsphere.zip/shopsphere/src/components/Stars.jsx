// CSS-only rating stars. The --rating variable controls how much of the row is filled.
export default function Stars({ rating }) {
  return (
    <span className="rating">
      <span className="stars" style={{ '--rating': rating }} role="img" aria-label={`Rated ${rating} out of 5`} />
      <span className="rating__num">{rating.toFixed(1)}</span>
    </span>
  );
}
