import { useEffect, useState } from 'react';
import { categories } from '../data/products.js';

/**
 * Listing controls. It owns no filter state of its own except the two
 * price text boxes; everything else comes from the URL via props.
 */
export default function FilterBar({ filters, brandOptions, resultCount, onCategory, onBrand, onInStock, onPrice, onSort, onReset }) {
  const [min, setMin] = useState(filters.minPrice);
  const [max, setMax] = useState(filters.maxPrice);
  useEffect(() => {
    setMin(filters.minPrice);
    setMax(filters.maxPrice);
  }, [filters.minPrice, filters.maxPrice]);

  return (
    <aside className="filters" aria-label="Filters and sorting">
      <div className="filters__group">
        <h2 className="filters__title">Category</h2>
        <div className="chips">
          <button type="button" className={`chip ${!filters.category ? 'chip--on' : ''}`} aria-pressed={!filters.category} onClick={() => onCategory('')}>All</button>
          {categories.map((c) => (
            <button key={c.slug} type="button" className={`chip ${filters.category === c.slug ? 'chip--on' : ''}`} aria-pressed={filters.category === c.slug} onClick={() => onCategory(c.slug)}>
              {c.name}
            </button>
          ))}
        </div>
      </div>

      <div className="filters__group">
        <h2 className="filters__title">Price (₹)</h2>
        <form
          className="price-range"
          onSubmit={(e) => {
            e.preventDefault();
            onPrice(min, max);
          }}
        >
          <label className="sr-only" htmlFor="min-price">Minimum price</label>
          <input id="min-price" type="number" min="0" inputMode="numeric" placeholder="Min" value={min} onChange={(e) => setMin(e.target.value)} />
          <span aria-hidden="true">–</span>
          <label className="sr-only" htmlFor="max-price">Maximum price</label>
          <input id="max-price" type="number" min="0" inputMode="numeric" placeholder="Max" value={max} onChange={(e) => setMax(e.target.value)} />
          <button type="submit" className="btn btn--small">Apply</button>
        </form>
      </div>

      <fieldset className="filters__group">
        <legend className="filters__title">Brand</legend>
        {brandOptions.map((brand) => (
          <label key={brand} className="check">
            <input type="checkbox" checked={filters.brands.includes(brand)} onChange={(e) => onBrand(brand, e.target.checked)} />
            {brand}
          </label>
        ))}
      </fieldset>

      <div className="filters__group">
        <label className="check">
          <input type="checkbox" checked={filters.inStock} onChange={(e) => onInStock(e.target.checked)} />
          In stock only
        </label>
      </div>

      <div className="filters__group">
        <label className="filters__title" htmlFor="sort">Sort by</label>
        <select id="sort" value={filters.sort} onChange={(e) => onSort(e.target.value)}>
          <option value="">Featured</option>
          <option value="price-asc">Price: low to high</option>
          <option value="price-desc">Price: high to low</option>
          <option value="rating">Rating</option>
          <option value="name">Name (A-Z)</option>
        </select>
      </div>

      <p className="muted" aria-live="polite">{resultCount} {resultCount === 1 ? 'product' : 'products'} found</p>
      <button type="button" className="btn btn--outline btn--block" onClick={onReset}>Reset filters</button>
    </aside>
  );
}
