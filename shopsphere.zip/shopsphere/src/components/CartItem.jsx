import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import ProductImage from './ProductImage.jsx';
import { useCart } from '../context/CartContext.jsx';
import { formatCurrency } from '../utils/format.js';

// One row in the cart: quantity controls (- / + / typed), remove, line total.
export default function CartItem({ line }) {
  const { setQuantity, removeItem } = useCart();
  const [draft, setDraft] = useState(String(line.quantity));

  // Keep the box in sync when quantity changes through the +/- buttons.
  useEffect(() => setDraft(String(line.quantity)), [line.quantity]);

  const commitDraft = () => {
    setQuantity(line.productId, Number(draft));
    setDraft(String(Math.max(1, Math.min(Math.floor(Number(draft)) || 1, line.stock))));
  };

  return (
    <li className="cart-item">
      <Link to={`/products/${line.productId}`} className="cart-item__img">
        <ProductImage product={line} />
      </Link>
      <div className="cart-item__info">
        <p className="card__brand">{line.brand}</p>
        <Link to={`/products/${line.productId}`} className="cart-item__name">{line.productName}</Link>
        <p className="muted">{formatCurrency(line.price)} each · {line.stock} in stock</p>
        <div className="qty" role="group" aria-label={`Quantity for ${line.productName}`}>
          <button type="button" className="qty__btn" onClick={() => setQuantity(line.productId, line.quantity - 1)} disabled={line.quantity <= 1} aria-label="Decrease quantity">−</button>
          <input
            className="qty__input"
            type="number"
            inputMode="numeric"
            min="1"
            max={line.stock}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onBlur={commitDraft}
            onKeyDown={(e) => e.key === 'Enter' && commitDraft()}
            aria-label={`Quantity of ${line.productName}`}
          />
          <button type="button" className="qty__btn" onClick={() => setQuantity(line.productId, line.quantity + 1)} disabled={line.quantity >= line.stock} aria-label="Increase quantity">+</button>
        </div>
      </div>
      <div className="cart-item__side">
        <strong>{formatCurrency(line.price * line.quantity)}</strong>
        <button type="button" className="link-btn" onClick={() => removeItem(line.productId)}>Remove</button>
      </div>
    </li>
  );
}
