// Small confirmation message shown after actions like "Add to cart".
// role="status" makes screen readers announce it politely.
export default function Toast({ toast, onClose }) {
  return (
    <div className="toast-region" role="status" aria-live="polite">
      {toast && (
        <div className="toast" key={toast.id}>
          <span>{toast.message}</span>
          <button type="button" className="toast__close" onClick={onClose} aria-label="Dismiss message">
            ×
          </button>
        </div>
      )}
    </div>
  );
}
