import { useRef } from 'react';
import { Link } from 'react-router-dom';
import ProductImage from './ProductImage.jsx';
import Stars from './Stars.jsx';
import { useCart } from '../context/CartContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { track } from '../analytics/dataLayer.js';
import { EVENTS } from '../analytics/events.js';
import { toProductItem } from '../analytics/helpers.js';
import { useProductImpression } from '../analytics/useImpression.js';
import { formatCurrency, discountPercent } from '../utils/format.js';

/**
 * One product tile.
 * position   = 1-based place in the list (reported to analytics)
 * listName   = which list it belongs to, e.g. "Featured Products"
 * renderKey  = identifies this render of the list (impression dedupe)
 * onProductClick = optional override (search results report search_result_click instead)
 */
export default function ProductCard({ product, position, listName, renderKey, onProductClick }) {
  const cardRef = useRef(null);
  const { addItem } = useCart();
  const { showToast } = useToast();
  const off = discountPercent(product.mrp, product.price);
  const soldOut = product.stock === 0;

  useProductImpression(cardRef, product, position, listName, renderKey);

  function handleClick() {
    if (onProductClick) {
      onProductClick(product, position);
    } else {
      track(EVENTS.PRODUCT_CLICK, {
        ecommerce: { currency: 'INR', items: [toProductItem(product, { position, listName })] },
      });
    }
  }

  function handleAdd() {
    const { added } = addItem(product, 1, { position, listName });
    showToast(added ? `${product.productName} added to cart` : 'You already have the maximum in stock in your cart');
  }

  return (
    <article className="card" ref={cardRef}>
      <Link
        to={`/products/${product.productId}`}
        state={{ listName, position }}
        className="card__link"
        onClick={handleClick}
      >
        <div className="card__media">
          <ProductImage product={product} />
          {off > 0 && !soldOut && <span className="badge badge--sale">{off}% off</span>}
          {soldOut && <span className="badge badge--muted">Out of stock</span>}
        </div>
        <div className="card__body">
          <p className="card__brand">{product.brand}</p>
          <h3 className="card__title">{product.productName}</h3>
          <Stars rating={product.rating} />
          <p className="price">
            <span className="price__now">{formatCurrency(product.price)}</span>
            {off > 0 && <s className="price__mrp">{formatCurrency(product.mrp)}</s>}
          </p>
        </div>
      </Link>
      <div className="card__actions">
        <button type="button" className="btn btn--primary btn--block" onClick={handleAdd} disabled={soldOut}>
          {soldOut ? 'Out of stock' : 'Add to cart'}
        </button>
      </div>
    </article>
  );
}
