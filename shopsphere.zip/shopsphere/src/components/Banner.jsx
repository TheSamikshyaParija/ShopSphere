import { useState } from 'react';
import { Link } from 'react-router-dom';
import { track } from '../analytics/dataLayer.js';
import { EVENTS } from '../analytics/events.js';

// promotion object used by banner_click and promo_click
const toPromotion = (b) => ({
  promotionId: b.promotionId,
  promotionName: b.promotionName,
  creative: b.creative,
  position: b.position,
});

/** Hero carousel. Manual controls only (no autoplay), so nothing moves without the user. */
export function HeroCarousel({ banners }) {
  const [index, setIndex] = useState(0);
  const banner = banners[index];
  const go = (next) => setIndex((next + banners.length) % banners.length);

  return (
    <section className="hero" aria-roledescription="carousel" aria-label="Featured promotions">
      <div className={`hero__slide hero__slide--${banner.theme}`} role="group" aria-roledescription="slide" aria-label={`${index + 1} of ${banners.length}`}>
        <div className="hero__text">
          <h1 className="hero__title">{banner.title}</h1>
          <p className="hero__sub">{banner.subtitle}</p>
          <Link
            to={banner.target}
            className="btn btn--light"
            onClick={() => track(EVENTS.BANNER_CLICK, { promotion: toPromotion(banner) })}
          >
            {banner.cta}
          </Link>
        </div>
        <div className="hero__art" aria-hidden="true">
          <span />
          <span />
          <span />
        </div>
      </div>
      <div className="hero__controls">
        <button type="button" className="icon-btn" onClick={() => go(index - 1)} aria-label="Previous banner">‹</button>
        <div className="hero__dots">
          {banners.map((b, i) => (
            <button
              key={b.promotionId}
              type="button"
              className={`dot ${i === index ? 'dot--active' : ''}`}
              onClick={() => setIndex(i)}
              aria-label={`Show banner ${i + 1}: ${b.title}`}
              aria-current={i === index}
            />
          ))}
        </div>
        <button type="button" className="icon-btn" onClick={() => go(index + 1)} aria-label="Next banner">›</button>
      </div>
    </section>
  );
}

export function PromoBanner({ banner }) {
  return (
    <Link
      to={banner.target}
      className={`promo promo--${banner.theme}`}
      onClick={() => track(EVENTS.PROMO_CLICK, { promotion: toPromotion(banner) })}
    >
      <strong className="promo__title">{banner.title}</strong>
      <span className="promo__sub">{banner.subtitle}</span>
    </Link>
  );
}
