// Local SVG placeholder tile showing the product initials (no remote images).
// `variant` 0-3 changes the shapes, used for the gallery thumbnails.
const COLORS = {
  Electronics: { fg: '#1d3fd1', bg: '#dfe6ff' },
  Footwear: { fg: '#0f766e', bg: '#d6f3ee' },
  Apparel: { fg: '#b4235a', bg: '#fde1ec' },
  'Home & Kitchen': { fg: '#a14a07', bg: '#fdecc9' },
};

function initialsOf(name) {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0])
    .join('')
    .toUpperCase();
}

export default function ProductImage({ product, variant = 0, className = '' }) {
  const { fg, bg } = COLORS[product.productCategory] || COLORS.Electronics;
  const shapes = [
    <circle key="a" cx="320" cy="90" r="120" fill={fg} opacity="0.14" />,
    <rect key="b" x="-40" y="260" width="300" height="200" rx="40" fill={fg} opacity="0.14" />,
    <circle key="c" cx="60" cy="330" r="130" fill={fg} opacity="0.14" />,
    <rect key="d" x="230" y="-30" width="220" height="220" rx="60" fill={fg} opacity="0.14" />,
  ];
  return (
    <svg
      className={`product-image ${className}`}
      viewBox="0 0 400 400"
      role="img"
      aria-label={`${product.productName} (placeholder image)`}
    >
      <rect width="400" height="400" fill={bg} />
      {shapes[variant % shapes.length]}
      <text x="200" y="228" textAnchor="middle" fontSize="120" fontWeight="700" fill={fg} fontFamily="inherit">
        {initialsOf(product.productName)}
      </text>
    </svg>
  );
}
