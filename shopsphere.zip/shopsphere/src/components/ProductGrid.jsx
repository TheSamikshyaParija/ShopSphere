import ProductCard from './ProductCard.jsx';
import { useForgetImpressions } from '../analytics/useImpression.js';

// Placeholder tiles shown while a list is "loading".
export function SkeletonGrid({ count = 8 }) {
  return (
    <ul className="grid" aria-hidden="true">
      {Array.from({ length: count }, (_, i) => (
        <li key={i} className="skeleton-card">
          <div className="skeleton skeleton--img" />
          <div className="skeleton skeleton--line" />
          <div className="skeleton skeleton--line short" />
        </li>
      ))}
    </ul>
  );
}

export default function ProductGrid({ products, listName, loading = false, onProductClick }) {
  // One "render" of this list = this list name + this exact set/order of products.
  const renderKey = `${listName}|${products.map((p) => p.productId).join(',')}`;
  useForgetImpressions(renderKey);

  if (loading) return <SkeletonGrid />;
  return (
    <ul className="grid">
      {products.map((product, index) => (
        <li key={product.productId}>
          <ProductCard
            product={product}
            position={index + 1}
            listName={listName}
            renderKey={renderKey}
            onProductClick={onProductClick}
          />
        </li>
      ))}
    </ul>
  );
}
