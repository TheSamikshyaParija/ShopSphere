import { useState } from 'react';
import FormField from './FormField.jsx';
import { track } from '../analytics/dataLayer.js';
import { EVENTS } from '../analytics/events.js';
import { validateEmail } from '../utils/validators.js';

export default function NewsletterForm() {
  const [email, setEmail] = useState('');
  const [error, setError] = useState(null);
  const [done, setDone] = useState(false);

  function handleSubmit(e) {
    e.preventDefault();
    const err = validateEmail(email);
    setError(err);
    if (err) {
      // Report WHICH field failed and WHY - never what was typed.
      track(EVENTS.FORM_ERROR, { formName: 'newsletter', fieldName: 'email', errorType: err.type });
      return;
    }
    // The email address is deliberately NOT sent to the data layer (PII).
    track(EVENTS.NEWSLETTER_SIGNUP, { formName: 'newsletter', location: 'home' });
    setDone(true);
    setEmail('');
  }

  if (done) {
    return (
      <p className="notice notice--ok" role="status">
        Thanks for subscribing! (Demo only: nothing was saved or sent.)
      </p>
    );
  }
  return (
    <form className="newsletter__form" onSubmit={handleSubmit} noValidate>
      <FormField
        id="newsletter-email"
        label="Email address"
        type="email"
        placeholder="you@example.com"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        error={error}
        autoComplete="off"
      />
      <button type="submit" className="btn btn--primary">Subscribe</button>
    </form>
  );
}
