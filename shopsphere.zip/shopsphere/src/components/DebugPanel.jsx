// DEV-ONLY panel: shows live window.dataLayer events. It is lazy-loaded only
// when import.meta.env.DEV is true, so it is not part of the production build.
import { useEffect, useState } from 'react';

export default function DebugPanel() {
  const [open, setOpen] = useState(false);
  const [events, setEvents] = useState(() => [...(window.dataLayer || [])]);

  useEffect(() => {
    const onPush = (e) => setEvents((prev) => [...prev, e.detail]);
    window.addEventListener('shopsphere:dl', onPush);
    return () => window.removeEventListener('shopsphere:dl', onPush);
  }, []);

  function clear() {
    window.dataLayer.length = 0; // empties the real array too (dedupe guards stay)
    setEvents([]);
  }

  return (
    <div className="debug">
      {open && (
        <div className="debug__panel" role="region" aria-label="Data layer debug panel">
          <div className="debug__head">
            <strong>dataLayer ({events.length})</strong>
            <button type="button" className="btn btn--small" onClick={clear}>Clear</button>
          </div>
          <ol className="debug__list" reversed>
            {[...events].reverse().map((ev) => (
              <li key={ev.eventId}>
                <details>
                  <summary>
                    <span className="debug__name">{ev.event}</span>
                    <span className="debug__time">{ev.timestamp.slice(11, 19)}</span>
                  </summary>
                  <pre>{JSON.stringify(ev, null, 2)}</pre>
                </details>
              </li>
            ))}
          </ol>
        </div>
      )}
      <button type="button" className="debug__toggle" onClick={() => setOpen((o) => !o)} aria-expanded={open}>
        {open ? 'Hide' : 'DL'} {!open && events.length > 0 && <span>({events.length})</span>}
      </button>
    </div>
  );
}
