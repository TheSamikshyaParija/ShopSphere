import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { track } from '../analytics/dataLayer.js';
import { EVENTS } from '../analytics/events.js';
import { searchProducts } from '../data/products.js';

export default function SearchBar() {
  const navigate = useNavigate();
  const location = useLocation();
  const [term, setTerm] = useState('');

  // Keep the box in sync with the URL (e.g. after pressing Back).
  useEffect(() => {
    setTerm(location.pathname === '/search' ? new URLSearchParams(location.search).get('q') || '' : '');
  }, [location.pathname, location.search]);

  function handleSubmit(e) {
    e.preventDefault();
    const searchTerm = term.trim();
    if (!searchTerm) return;
    track(EVENTS.SEARCH_SUBMIT, { searchTerm, resultCount: searchProducts(searchTerm).length });
    navigate(`/search?q=${encodeURIComponent(searchTerm)}`);
  }

  return (
    <form className="searchbar" role="search" onSubmit={handleSubmit}>
      <label htmlFor="site-search" className="sr-only">Search products</label>
      <input
        id="site-search"
        type="search"
        placeholder="Search products, brands..."
        value={term}
        onChange={(e) => setTerm(e.target.value)}
        autoComplete="off"
      />
      <button type="submit" className="searchbar__btn" aria-label="Search">
        <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
          <circle cx="11" cy="11" r="6.5" fill="none" stroke="currentColor" strokeWidth="2" />
          <path d="M16 16l5 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      </button>
    </form>
  );
}
