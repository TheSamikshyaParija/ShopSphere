import { Link } from 'react-router-dom';
import { track } from '../analytics/dataLayer.js';
import { EVENTS } from '../analytics/events.js';
import { getDomain } from '../analytics/helpers.js';

const OUTBOUND = [
  { name: 'Adobe Analytics docs', url: 'https://experienceleague.adobe.com/docs/analytics.html' },
  { name: 'MDN Web Docs', url: 'https://developer.mozilla.org/' },
];

export default function Footer() {
  const navClick = (linkName, linkUrl) =>
    track(EVENTS.NAV_CLICK, { linkName, linkUrl, linkLocation: 'footer' });

  return (
    <footer className="site-footer">
      <div className="container site-footer__grid">
        <div>
          <p className="site-footer__brand">ShopSphere</p>
          <p className="site-footer__text">A demo store for practising analytics implementation. No real orders, no real payments.</p>
        </div>
        <nav aria-label="Company">
          <h2 className="site-footer__heading">Company</h2>
          <ul>
            <li><Link to="/about" onClick={() => navClick('about', '/about')}>About us</Link></li>
            <li><Link to="/contact" onClick={() => navClick('contact', '/contact')}>Contact</Link></li>
            <li><Link to="/products" onClick={() => navClick('all_products', '/products')}>All products</Link></li>
          </ul>
        </nav>
        <div>
          <h2 className="site-footer__heading">Resources</h2>
          <ul>
            <li>
              {/* A real file in /public. The download attribute makes the browser save it. */}
              <a
                href="/shopsphere-size-guide.txt"
                download
                onClick={() => track(EVENTS.FILE_DOWNLOAD, { fileName: 'shopsphere-size-guide.txt', fileType: 'txt' })}
              >
                Size guide (download)
              </a>
            </li>
            {OUTBOUND.map((link) => (
              <li key={link.url}>
                <a
                  href={link.url}
                  target="_blank"
                  rel="noopener"
                  onClick={() =>
                    track(EVENTS.OUTBOUND_CLICK, { destinationUrl: link.url, destinationDomain: getDomain(link.url), linkName: link.name })
                  }
                >
                  {link.name} <span className="sr-only">(opens in a new tab)</span>
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <p className="site-footer__legal container">© 2026 ShopSphere demo. Not a real store.</p>
    </footer>
  );
}
