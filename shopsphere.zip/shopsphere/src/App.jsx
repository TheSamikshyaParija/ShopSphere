import { Suspense, lazy, useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import Header from './components/Header.jsx';
import Footer from './components/Footer.jsx';
import AppRoutes from './routes.jsx';
import { initCartAbandonment } from './analytics/cartAbandonment.js';

// The debug panel is only loaded in development; Vite removes it from production builds.
const DebugPanel = import.meta.env.DEV ? lazy(() => import('./components/DebugPanel.jsx')) : null;

// On every route change: scroll to the top and move focus to <main> (helps keyboard and screen-reader users).
function RouteEffects({ mainRef }) {
  const { pathname } = useLocation();
  const first = useRef(true);
  useEffect(() => {
    window.scrollTo(0, 0);
    if (first.current) first.current = false;
    else mainRef.current?.focus({ preventScroll: true });
  }, [pathname, mainRef]);
  return null;
}

export default function App() {
  const mainRef = useRef(null);

  // Register the abandonment listeners once. The module guard also protects against StrictMode.
  useEffect(() => {
    initCartAbandonment();
  }, []);

  return (
    <>
      <a href="#main" className="skip-link">Skip to main content</a>
      <Header />
      <RouteEffects mainRef={mainRef} />
      <main id="main" ref={mainRef} tabIndex={-1}>
        <AppRoutes />
      </main>
      <Footer />
      {DebugPanel && (
        <Suspense fallback={null}>
          <DebugPanel />
        </Suspense>
      )}
    </>
  );
}
