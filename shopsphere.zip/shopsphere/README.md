# ShopSphere (Phase 2: analytics-ready storefront)

A demo e-commerce site (React 18 + Vite, plain CSS) built for practising Adobe Analytics implementation.
**It contains NO Adobe code** (no Launch/Tags, AppMeasurement or Web SDK). Everything is reported to `window.dataLayer`, ready for a tag manager to read in a later phase.

No backend, no external requests at runtime, no personal data collected. Products, payments and orders are all simulated in the browser.

## Setup

```bash
npm install
npm run dev        # http://localhost:5173 (dev server, data layer logging + debug panel ON)
npm run build      # production build into dist/
npm run preview    # serve the production build locally
```

Checks (all optional, none need a browser):

```bash
npm run check      # data, order ID, cart maths, data layer guards, purchase-once (plain Node)
npm run smoke      # renders all 10 routes to HTML to catch crashes
# Simulated-browser test (clicks through the app with StrictMode ON). jsdom is not a project dependency:
npm install --no-save jsdom && node scripts/dom-test.mjs
```

## Project structure

```
shopsphere/
  index.html                    Vite entry. Contains the commented Adobe embed placeholder
  public/                       favicon.svg, shopsphere-size-guide.txt (the downloadable file)
  scripts/                      sanity-check.mjs, smoke-render.mjs, dom-test.mjs
  src/
    main.jsx, App.jsx, routes.jsx, styles.css
    components/   Header, Footer, SearchBar, ProductCard, ProductGrid, ProductImage, Stars,
                  Banner (HeroCarousel + PromoBanner), FilterBar, CartItem, FormField,
                  NewsletterForm, Toast, DebugPanel (dev only)
    pages/        Home, ProductList, ProductDetail, SearchResults, Cart, Checkout,
                  OrderConfirmation, About, Contact, NotFound
    context/      CartContext.jsx (cart state + localStorage + totals), ToastContext.jsx
    data/         products.js (24 products, categories, banners, search helper)
    analytics/    dataLayer.js, events.js, usePageView.js, useImpression.js, useOnce.js,
                  helpers.js, orderStorage.js, cartAbandonment.js
    utils/        format.js, orderId.js, cartMath.js, validators.js, productFilters.js
```

Where to put the Adobe embed code later: the clearly marked comment block in `index.html`
(Vite requires `index.html` in the project root, not in `public/`).

## Routes

| Route | Page | pageType |
|---|---|---|
| `/` | Home | home |
| `/products` | Product listing (`?category=&minPrice=&maxPrice=&brand=&inStock=1&sort=`) | listing |
| `/products/:productId` | Product detail (e.g. `/products/SKU-101`) | product |
| `/search?q=` | Search results | search |
| `/cart` | Cart | cart |
| `/checkout` | 3-step checkout | checkout |
| `/order-confirmation` | Reads the stored order. Never creates one | confirmation |
| `/about`, `/contact` | Content pages | content |
| `*` | Not found | error |

Category slugs: `electronics`, `footwear`, `apparel`, `home-kitchen`. Sort values: `price-asc`, `price-desc`, `rating`, `name`.

## Data layer contract

* `window.dataLayer` is created in `src/analytics/dataLayer.js` as soon as the app loads.
* Everything is sent with `track(eventName, payload, { onceKey? })`. It pushes
  `{ event, timestamp (ISO), eventId (unique), ...payload }` and, in dev only, logs `[ShopSphere DL] ...` to the console.
* Guards: the same `eventId` can never be pushed twice, and the same `onceKey` (for example `purchase:ORDER-...`) can never be pushed twice per page load.
* `setPageState(page)` pushes a `page_view` with `pageName, pageType, siteSection, pageUrl, pageTitle, referrer, language` and, when present, `campaign: { utm_source, utm_medium, utm_campaign, utm_content, utm_term, cid }`.
  `referrer` is `document.referrer` for the first page and the previous URL after in-app navigation.
* Campaign params are read from the **current URL only** (they are not remembered across pages; persisting the landing campaign is a good Phase 3 topic).
* `usePageView(page, extraKey?)` fires one `page_view` per route change and is safe under React 18 StrictMode.
* Payloads are structured objects only. No DOM scraping and no PII (no name, address, phone, email, typed field values).
* Naming: all event names are `snake_case` constants in `src/analytics/events.js`.

### Shared shapes

```js
// product object
{ productId, productName, productCategory, brand, price, quantity, currency, position?, listName? }

// ecommerce object
{ currency: 'INR', items: [product...], cartValue, cartQuantity, transaction?: { orderId, revenue, tax, shipping, paymentMethod } }

// promotion object
{ promotionId, promotionName, creative, position }
```

**Revenue definition:** `transaction.revenue` = item subtotal (price x quantity), **excluding** tax and shipping, which are reported separately. The grand total is stored on the order as `total` but is not part of the transaction object.
For `add_to_cart`, `remove_from_cart` and `update_quantity`, `ecommerce.items` describes only the product that changed, while `cartValue` / `cartQuantity` describe the whole cart afterwards.

## Event catalog

| Event | Fires when | Payload (besides event/timestamp/eventId) |
|---|---|---|
| `page_view` | Once per route change (and per new search term) | `pageName, pageType, siteSection, pageUrl, pageTitle, referrer, language, campaign?` |
| `nav_click` | Header/footer link that is not a category | `linkName, linkUrl, linkLocation` (`header`/`footer`) |
| `category_select` | Any category link/tile/chip | `categoryName, categorySlug, source` (`header_menu`, `home_tile`, `listing_filter`, `search_empty`) |
| `banner_click` | Hero carousel CTA | `promotion` |
| `promo_click` | Promo banner | `promotion` |
| `product_impression` | A product card is 50% visible, once per product per list render | `ecommerce.items[1]` with `position, listName` |
| `product_click` | Product card clicked (not on search results) | `ecommerce.items[1]` with `position, listName` |
| `product_view` | Product detail opened, once per product | `ecommerce.items[1]` (`position/listName` of the card clicked, if any) |
| `search_submit` | Search form submitted or suggestion chip clicked | `searchTerm, resultCount, source?` |
| `search_empty` | A search with 0 results is shown | `searchTerm, resultCount: 0` |
| `search_result_click` | Result clicked on /search | `searchTerm, position, resultCount, ecommerce.items[1]` |
| `filter_apply` | Brand / price / in-stock / reset changed on the listing | `filterName, filterValue, filterAction, resultCount, listName` |
| `sort_apply` | Sort changed | `sortOption, resultCount, listName` |
| `add_to_cart` | Add to cart (card or detail page) | `ecommerce` (items = what was added) |
| `remove_from_cart` | Remove clicked in cart | `ecommerce` |
| `update_quantity` | Quantity changed in cart | `previousQuantity, newQuantity, ecommerce` |
| `cart_view` | Cart page opened | `ecommerce` |
| `checkout_start` | Checkout opened with items in the cart | `ecommerce` |
| `shipping_submit` | Shipping form submitted | `success` (boolean only) |
| `payment_method_select` | Payment option chosen | `paymentMethod` (`card`/`upi`/`cod`) |
| `purchase` | **Once**, when Place Order succeeds | `ecommerce` with `transaction` |
| `newsletter_signup` | Valid newsletter form | `formName, location` (no email) |
| `form_error` | Validation fails | `formName, fieldName, errorType` (`required`/`invalid_format`/`too_short`; never the value) |
| `outbound_click` | Footer external link | `destinationUrl, destinationDomain, linkName` |
| `file_download` | Size guide download link | `fileName, fileType` |
| `cart_abandon` | Tab hidden / page left with items in the cart (once per cart contents) | `lastPage, inCheckout, ecommerce` |

List names used: `Featured Products`, `All Products`, `Category: <name>`, `Related Products`, `Search Results`, `Product Detail` (add to cart on the detail page).

### How the purchase is protected against duplicates

1. Place Order is the only code that creates an order (`ORDER-YYYYMMDD-XXXXXX`) and saves it to `localStorage["shopsphere_last_order"]` with `purchaseTracked: false`.
2. `trackPurchaseOnce()` sends `purchase`, guarded by the `purchaseTracked` flag and the in-memory `onceKey`, then sets the flag to `true`.
3. `/order-confirmation` only **reads** the stored order. Refreshing it, or visiting it with no order, never creates an order or fires `purchase`. With no order it shows a message and redirects to `/`.

The order stores items, revenue, shipping, tax, total and payment method, and no personal data.

## Inspecting the data layer

* **Console:** `window.dataLayer` (array of all events). Handy: `console.table(window.dataLayer.map(e => ({ event: e.event, page: e.pageName })))`.
  Filter: `dataLayer.filter(e => e.event === 'add_to_cart')`.
* **Dev logging:** with `npm run dev` every push is logged with a `[ShopSphere DL]` prefix.
* **Debug panel:** dev only. The round **DL** button, bottom-left, opens a live list. Click an event to expand its JSON. **Clear** empties the panel and the real `window.dataLayer` array.
  The panel is not included in `npm run build` output.
* **Storage:** DevTools > Application > Local Storage: `shopsphere_cart`, `shopsphere_last_order`.

## Simulating a campaign landing

Open any of these (dev server shown) and check the first `page_view` for a `campaign` object:

```
http://localhost:5173/?utm_source=google&utm_medium=cpc&utm_campaign=summer_sale&utm_content=headline_a&utm_term=wireless+headphones
http://localhost:5173/?utm_source=newsletter&utm_medium=email&utm_campaign=diwali_2026&cid=em-1042
http://localhost:5173/products?category=footwear&utm_source=instagram&utm_medium=social&utm_campaign=step_into_comfort
http://localhost:5173/products/SKU-101?utm_source=affiliate&utm_medium=referral&utm_campaign=review_site&cid=aff-77
```

Then click around: the params are present on the landing `page_view` only (current-URL parsing). Listing filters keep unrelated URL params.

## Manual tests for browser-only behaviour

These depend on a real browser, so verify them by hand (the automated tests use a simulated browser):

* **Real IntersectionObserver:** scroll a product grid; each card should log one `product_impression` only after it is at least half visible, once per list render.
* **Abandonment:** add an item, switch to another browser tab (or close the tab). Check `cart_abandon` appears in the console/panel when you come back, once, and that the cart is still full.
* **File download:** the footer "Size guide" link should save `shopsphere-size-guide.txt` and log `file_download`.
* **Outbound links:** open in a new tab and log `outbound_click`.
* **Back/forward and refresh:** refreshing any page resets the in-memory guards (as intended), reloading `/order-confirmation` must show the same order ID and no `purchase`.
